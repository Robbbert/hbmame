// license:BSD-3-Clause
// copyright-holders:Robbbert
#include "../mame/drivers/dkong.cpp"

static INPUT_PORTS_START( dkongex )
	PORT_INCLUDE( dkong )
	PORT_MODIFY("DSW0")
	PORT_DIPNAME( 0x70, 0x00, DEF_STR( Coinage ) )
	PORT_DIPSETTING(    0x70, "Freeplay" )
	PORT_DIPSETTING(    0x50, DEF_STR( 4C_1C ) )
	PORT_DIPSETTING(    0x30, DEF_STR( 3C_1C ) )
	PORT_DIPSETTING(    0x10, DEF_STR( 2C_1C ) )
	PORT_DIPSETTING(    0x00, DEF_STR( 1C_1C ) )
	PORT_DIPSETTING(    0x20, DEF_STR( 1C_2C ) )
	PORT_DIPSETTING(    0x40, DEF_STR( 1C_3C ) )
	PORT_DIPSETTING(    0x60, DEF_STR( 1C_4C ) )
INPUT_PORTS_END

static INPUT_PORTS_START( dkrdemo )
	PORT_INCLUDE( dkong )
	PORT_MODIFY("DSW0")
	PORT_DIPNAME( 0x03, 0x00, DEF_STR( Lives ) )       PORT_DIPLOCATION( "SW1:!1,!2" )
	PORT_DIPSETTING(    0x00, "3" )
	PORT_DIPSETTING(    0x01, "5" )
	PORT_DIPSETTING(    0x02, "7" )
	PORT_DIPSETTING(    0x03, "9" )
	PORT_DIPNAME( 0x0c, 0x00, DEF_STR( Bonus_Life ) )   PORT_DIPLOCATION( "SW1:!3,!4" )
	PORT_DIPSETTING(    0x00, "10000" )
	PORT_DIPSETTING(    0x04, "15000" ) // and each additional 150k
	PORT_DIPSETTING(    0x08, "25000" ) // and each additional 250k
	PORT_DIPSETTING(    0x0c, "35000" ) // and each additional 350k
	PORT_DIPNAME( 0x30, 0x00, DEF_STR( Coinage ) )      PORT_DIPLOCATION( "SW1:!5,!6" )
	PORT_DIPSETTING(    0x30, "Free Play" )
	PORT_DIPSETTING(    0x10, DEF_STR( 2C_1C ) )
	PORT_DIPSETTING(    0x00, DEF_STR( 1C_1C ) )
	PORT_DIPSETTING(    0x20, DEF_STR( 1C_2C ) )
	PORT_DIPNAME( 0x40, 0x00, DEF_STR( Difficulty ) )   PORT_DIPLOCATION( "SW1:!8" )
	PORT_DIPSETTING(    0x00, DEF_STR( Normal ) )
	PORT_DIPSETTING(    0x40, DEF_STR( Hard ) )
	PORT_DIPNAME( 0x80, 0x80, DEF_STR( Cabinet ) )      PORT_DIPLOCATION( "SW1:!8" )
	PORT_DIPSETTING(    0x80, DEF_STR( Upright ) )
	PORT_DIPSETTING(    0x00, DEF_STR( Cocktail ) )
INPUT_PORTS_END



/* same as mame 'dkongf' except 4th rom is different */
ROM_START( dkongex )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dk_f.5et",       0x0000, 0x1000, CRC(00b7efaf) SHA1(97ed5930eb5d0cb98a9008b1d329ba7f3b8b8dbf) )
	ROM_LOAD( "dk_f.5ct",       0x1000, 0x1000, CRC(88af9b69) SHA1(c5621dd8198c333b3fa32fdece60ee5a3d8b2276) )
	ROM_LOAD( "dk_f.5bt",       0x2000, 0x1000, CRC(de74ad91) SHA1(c80227361bdbc565e9f5764e6364b52d40ca778a) )
	ROM_LOAD( "dkongex.5at",    0x3000, 0x1000, CRC(9fa3e5b7) SHA1(5c34170f762a147d5285d17d6689fd64dab99ff2) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "v_5h_b.bin",     0x0000, 0x0800, CRC(12c8c95d) SHA1(a57ff5a231c45252a63b354137c920a1379b70a3) )
	ROM_LOAD( "v_3pt.bin",      0x0800, 0x0800, CRC(15e9c5e9) SHA1(976eb1e18c74018193a35aa86cff482ebfc5cc4e) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "l_4m_b.bin",     0x0000, 0x0800, CRC(59f8054d) SHA1(793dba9bf5a5fe76328acdfb90815c243d2a65f1) )
	ROM_LOAD( "l_4n_b.bin",     0x0800, 0x0800, CRC(672e4714) SHA1(92e5d379f4838ac1fa44d448ce7d142dae42102f) )
	ROM_LOAD( "l_4r_b.bin",     0x1000, 0x0800, CRC(feaa59ee) SHA1(ecf95db5a20098804fc8bd59232c66e2e0ed3db4) )
	ROM_LOAD( "l_4s_b.bin",     0x1800, 0x0800, CRC(20f2ef7e) SHA1(3bc482a38bf579033f50082748ee95205b0f673d) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "c-2k.bpr",       0x0000, 0x0100, CRC(e273ede5) SHA1(b50ec9e1837c00c20fb2a4369ec7dd0358321127) )
	ROM_LOAD( "c-2j.bpr",       0x0100, 0x0100, CRC(d6412358) SHA1(f9c872da2fe8e800574ae3bf483fb3ccacc92eb3) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END


/* This set has the fixes proposed by Don Hodges at the page:
    http://donhodges.com/how_high_can_you_get.htm */
ROM_START( dkongp )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkongp_c_5et",   0x0000, 0x1000, CRC(2066139d) SHA1(2eaf4cd6eb18eacb210892a85147e70db58bee48) )
	ROM_LOAD( "c_5ct_g.bin",    0x1000, 0x1000, CRC(5ec461ec) SHA1(acb11a8fbdbb3ab46068385fe465f681e3c824bd) )
	ROM_LOAD( "c_5bt_g.bin",    0x2000, 0x1000, CRC(1c97d324) SHA1(c7966261f3a1d3296927e0b6ee1c58039fc53c1f) )
	ROM_LOAD( "c_5at_g.bin",    0x3000, 0x1000, CRC(b9005ac0) SHA1(3fe3599f6fa7c496f782053ddf7bacb453d197c4) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "v_5h_b.bin",     0x0000, 0x0800, CRC(12c8c95d) SHA1(a57ff5a231c45252a63b354137c920a1379b70a3) )
	ROM_LOAD( "v_3pt.bin",      0x0800, 0x0800, CRC(15e9c5e9) SHA1(976eb1e18c74018193a35aa86cff482ebfc5cc4e) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "l_4m_b.bin",     0x0000, 0x0800, CRC(59f8054d) SHA1(793dba9bf5a5fe76328acdfb90815c243d2a65f1) )
	ROM_LOAD( "l_4n_b.bin",     0x0800, 0x0800, CRC(672e4714) SHA1(92e5d379f4838ac1fa44d448ce7d142dae42102f) )
	ROM_LOAD( "l_4r_b.bin",     0x1000, 0x0800, CRC(feaa59ee) SHA1(ecf95db5a20098804fc8bd59232c66e2e0ed3db4) )
	ROM_LOAD( "l_4s_b.bin",     0x1800, 0x0800, CRC(20f2ef7e) SHA1(3bc482a38bf579033f50082748ee95205b0f673d) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "c-2k.bpr",       0x0000, 0x0100, CRC(e273ede5) SHA1(b50ec9e1837c00c20fb2a4369ec7dd0358321127) )
	ROM_LOAD( "c-2j.bpr",       0x0100, 0x0100, CRC(d6412358) SHA1(f9c872da2fe8e800574ae3bf483fb3ccacc92eb3) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dkrdemo )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkrdemo.5et",    0x0000, 0x1000, CRC(f9fdff29) SHA1(c2eb8f0ede8384369e17d8616f4ce063ae12b6c2) )
	ROM_LOAD( "dkrdemo.5ct",    0x1000, 0x1000, CRC(f48cb898) SHA1(470b8bee7f55e1d828abc0b1ec4b423392c83a78) )
	ROM_LOAD( "dkrdemo.5bt",    0x2000, 0x1000, CRC(660d43ec) SHA1(8bba334cec022ea851c4a82f6ecbc91c0708daea) )
	ROM_LOAD( "dkrdemo.5at",    0x3000, 0x1000, CRC(e59d406c) SHA1(7698e319ae191bb8bf7deeea5c4f18da04d73f73) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "v_5h_b.bin",     0x0000, 0x0800, CRC(12c8c95d) SHA1(a57ff5a231c45252a63b354137c920a1379b70a3) )
	ROM_LOAD( "v_3pt.bin",      0x0800, 0x0800, CRC(15e9c5e9) SHA1(976eb1e18c74018193a35aa86cff482ebfc5cc4e) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "l_4m_b.bin",     0x0000, 0x0800, CRC(59f8054d) SHA1(793dba9bf5a5fe76328acdfb90815c243d2a65f1) )
	ROM_LOAD( "l_4n_b.bin",     0x0800, 0x0800, CRC(672e4714) SHA1(92e5d379f4838ac1fa44d448ce7d142dae42102f) )
	ROM_LOAD( "l_4r_b.bin",     0x1000, 0x0800, CRC(feaa59ee) SHA1(ecf95db5a20098804fc8bd59232c66e2e0ed3db4) )
	ROM_LOAD( "l_4s_b.bin",     0x1800, 0x0800, CRC(20f2ef7e) SHA1(3bc482a38bf579033f50082748ee95205b0f673d) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "c-2k.bpr",       0x0000, 0x0100, CRC(e273ede5) SHA1(b50ec9e1837c00c20fb2a4369ec7dd0358321127) )
	ROM_LOAD( "c-2j.bpr",       0x0100, 0x0100, CRC(d6412358) SHA1(f9c872da2fe8e800574ae3bf483fb3ccacc92eb3) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( kong2600 )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "c_5et_g.bin",    0x0000, 0x1000, CRC(ba70b88b) SHA1(d76ebecfea1af098d843ee7e578e480cd658ac1a) )
	ROM_LOAD( "c_5ct_g.bin",    0x1000, 0x1000, CRC(5ec461ec) SHA1(acb11a8fbdbb3ab46068385fe465f681e3c824bd) )
	ROM_LOAD( "c_5bt_g.bin",    0x2000, 0x1000, CRC(1c97d324) SHA1(c7966261f3a1d3296927e0b6ee1c58039fc53c1f) )
	ROM_LOAD( "c_5at_g.bin",    0x3000, 0x1000, CRC(b9005ac0) SHA1(3fe3599f6fa7c496f782053ddf7bacb453d197c4) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "k2600.3n",       0x0000, 0x0800, CRC(0e6a2a6d) SHA1(7ebbcb78b269184cf588b5ad0b90f449d6d4e299) )
	ROM_LOAD( "k2600.3p",       0x0800, 0x0800, CRC(ca57e0f4) SHA1(12c7821fc9f7fee276f7aa27dd0421f565b0f469) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "k2600.7c",       0x0000, 0x0800, CRC(cf450a43) SHA1(efa772f92b890181c0823b8113e069b7c4400ede) )
	ROM_LOAD( "k2600.7d",       0x0800, 0x0800, CRC(d5046907) SHA1(1eb08ed67f6de04c4f3cb8f449503bbedc6207bc) )
	ROM_LOAD( "k2600.7e",       0x1000, 0x0800, CRC(1539fe2a) SHA1(ea599987a2d65ffe2d09ca0951529bde2d31b1be) )
	ROM_LOAD( "k2600.7f",       0x1800, 0x0800, CRC(77cc00ab) SHA1(7560bf4fd65c03f28f015abf64f83fc4ad7ae512) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "k2600.2k",       0x0000, 0x0100, CRC(1e82d375) SHA1(8f2da5cedd1f62be08555dd0eb929eb41da5079d) )
	ROM_LOAD( "k2600.2j",       0x0100, 0x0100, CRC(2ab01dc8) SHA1(c25958d0706cabf997efe16fad71f454fc1ced0b) )
	ROM_LOAD( "k2600.5f",       0x0200, 0x0100, CRC(44988665) SHA1(68c474fc81aff46eae6c9a7ac6ab80288303e291) )
ROM_END

ROM_START( nadkong )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "c_5et_g.bin",    0x0000, 0x1000, CRC(ba70b88b) SHA1(d76ebecfea1af098d843ee7e578e480cd658ac1a) )
	ROM_LOAD( "c_5ct_g.bin",    0x1000, 0x1000, CRC(5ec461ec) SHA1(acb11a8fbdbb3ab46068385fe465f681e3c824bd) )
	ROM_LOAD( "c_5bt_g.bin",    0x2000, 0x1000, CRC(1c97d324) SHA1(c7966261f3a1d3296927e0b6ee1c58039fc53c1f) )
	ROM_LOAD( "c_5at_g.bin",    0x3000, 0x1000, CRC(b9005ac0) SHA1(3fe3599f6fa7c496f782053ddf7bacb453d197c4) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "nadkong.5h",     0x0000, 0x0800, CRC(88772f5b) SHA1(0fd6cbb593e87b863eb317b063151ef3b81565c2) )
	ROM_LOAD( "nadkong.3p",     0x0800, 0x0800, CRC(4c8aa728) SHA1(a277988d48f0d2f5d7cf9ef05eef222a36248cd3) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "nadkong.4m",     0x0000, 0x0800, CRC(2afbf9e6) SHA1(51e4f2f67903158b77574d55fcd17f302bc04a52) )
	ROM_LOAD( "nadkong.4n",     0x0800, 0x0800, CRC(4f077877) SHA1(4f2c2bc693b0e8d36114024b6eaeb37a3b5d853d) )
	ROM_LOAD( "nadkong.4r",     0x1000, 0x0800, CRC(d868da93) SHA1(c1c5d21f8c6a057fd5f54cab1eb4dbef06120405) )
	ROM_LOAD( "nadkong.4s",     0x1800, 0x0800, CRC(7ebfe9f3) SHA1(75bd16e9590ada93b061dee3ec7916e1e1f113c3) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "c-2k.bpr",       0x0000, 0x0100, CRC(e273ede5) SHA1(b50ec9e1837c00c20fb2a4369ec7dd0358321127) )
	ROM_LOAD( "c-2j.bpr",       0x0100, 0x0100, CRC(d6412358) SHA1(f9c872da2fe8e800574ae3bf483fb3ccacc92eb3) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dkong2m )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "c_5et_g.bin",    0x0000, 0x1000, CRC(ba70b88b) SHA1(d76ebecfea1af098d843ee7e578e480cd658ac1a) )
	ROM_LOAD( "c_5ct_g.bin",    0x1000, 0x1000, CRC(5ec461ec) SHA1(acb11a8fbdbb3ab46068385fe465f681e3c824bd) )
	ROM_LOAD( "c_5bt_g.bin",    0x2000, 0x1000, CRC(1c97d324) SHA1(c7966261f3a1d3296927e0b6ee1c58039fc53c1f) )
	ROM_LOAD( "c_5at_g.bin",    0x3000, 0x1000, CRC(b9005ac0) SHA1(3fe3599f6fa7c496f782053ddf7bacb453d197c4) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "v_5h_b.bin",     0x0000, 0x0800, CRC(12c8c95d) SHA1(a57ff5a231c45252a63b354137c920a1379b70a3) )
	ROM_LOAD( "v_3pt.bin",      0x0800, 0x0800, CRC(15e9c5e9) SHA1(976eb1e18c74018193a35aa86cff482ebfc5cc4e) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "l_4m_bm.bin",    0x0000, 0x0800, CRC(4b67ccf9) SHA1(8206436a0e5d1f7d5569f918eb87102f03b6cea3) )
	ROM_LOAD( "l_4n_bm.bin",    0x0800, 0x0800, CRC(32a708cb) SHA1(2c8b4d5179f10fb2e8e9da2012419bdfb436a545) )
	ROM_LOAD( "l_4r_bm.bin",    0x1000, 0x0800, CRC(22b5d5c4) SHA1(6bf39a5766786023cc18620283f12dbb9194cbfd) )
	ROM_LOAD( "l_4s_bm.bin",    0x1800, 0x0800, CRC(b212b185) SHA1(03d3586e80cafd2440d03d60b7a4c8808b0c6caa) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "c-2k.bpr",       0x0000, 0x0100, CRC(e273ede5) SHA1(b50ec9e1837c00c20fb2a4369ec7dd0358321127) )
	ROM_LOAD( "c-2j.bpr",       0x0100, 0x0100, CRC(d6412358) SHA1(f9c872da2fe8e800574ae3bf483fb3ccacc92eb3) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dkongpac )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "c_5et_g.bin",    0x0000, 0x1000, CRC(ba70b88b) SHA1(d76ebecfea1af098d843ee7e578e480cd658ac1a) )
	ROM_LOAD( "c_5ct_g.bin",    0x1000, 0x1000, CRC(5ec461ec) SHA1(acb11a8fbdbb3ab46068385fe465f681e3c824bd) )
	ROM_LOAD( "c_5bt_g.bin",    0x2000, 0x1000, CRC(1c97d324) SHA1(c7966261f3a1d3296927e0b6ee1c58039fc53c1f) )
	ROM_LOAD( "dkongpac.5a",    0x3000, 0x1000, CRC(56d28137) SHA1(62ad0783df4a4d8a7c45693966858b69343045ff) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "dkongpac.3n",    0x0000, 0x0800, CRC(1beba830) SHA1(04dce2464d0627b78d185924706f8ca38892d6d3) )
	ROM_LOAD( "dkongpac.3p",    0x0800, 0x0800, CRC(94d61766) SHA1(f45f10d523fefe0581dde42450b713cb94ce2072) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "dkongpac.7c",    0x0000, 0x0800, CRC(065e2713) SHA1(a32d506a247a692a10962c9e47024d51bbb52d22) )
	ROM_LOAD( "dkongpac.7d",    0x0800, 0x0800, CRC(a84b347d) SHA1(5a3e6fa3d520aef3c529e515d1e9fa464cbc6a78) )
	ROM_LOAD( "dkongpac.7e",    0x1000, 0x0800, CRC(6ae6f476) SHA1(a79927a1c7511bf510107d9ba5fcc8f284541259) )
	ROM_LOAD( "dkongpac.7f",    0x1800, 0x0800, CRC(9d293922) SHA1(14af1cd7f9854dec820c899d999be4623d0048b0) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "k2600.2k",       0x0000, 0x0100, CRC(1e82d375) SHA1(8f2da5cedd1f62be08555dd0eb929eb41da5079d) )
	ROM_LOAD( "k2600.2j",       0x0100, 0x0100, CRC(2ab01dc8) SHA1(c25958d0706cabf997efe16fad71f454fc1ced0b) )
	ROM_LOAD( "k2600.5f",       0x0200, 0x0100, CRC(44988665) SHA1(68c474fc81aff46eae6c9a7ac6ab80288303e291) )
ROM_END

ROM_START( dkrainbow )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "c_5et_g.bin",    0x0000, 0x1000, CRC(ba70b88b) SHA1(d76ebecfea1af098d843ee7e578e480cd658ac1a) )
	ROM_LOAD( "c_5ct_g.bin",    0x1000, 0x1000, CRC(5ec461ec) SHA1(acb11a8fbdbb3ab46068385fe465f681e3c824bd) )
	ROM_LOAD( "c_5bt_g.bin",    0x2000, 0x1000, CRC(1c97d324) SHA1(c7966261f3a1d3296927e0b6ee1c58039fc53c1f) )
	ROM_LOAD( "c_5at_g.bin",    0x3000, 0x1000, CRC(b9005ac0) SHA1(3fe3599f6fa7c496f782053ddf7bacb453d197c4) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "v_5h_b.bin",     0x0000, 0x0800, CRC(12c8c95d) SHA1(a57ff5a231c45252a63b354137c920a1379b70a3) )
	ROM_LOAD( "v_3pt.bin",      0x0800, 0x0800, CRC(15e9c5e9) SHA1(976eb1e18c74018193a35aa86cff482ebfc5cc4e) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "l_4m_b.bin",     0x0000, 0x0800, CRC(59f8054d) SHA1(793dba9bf5a5fe76328acdfb90815c243d2a65f1) )
	ROM_LOAD( "l_4n_b.bin",     0x0800, 0x0800, CRC(672e4714) SHA1(92e5d379f4838ac1fa44d448ce7d142dae42102f) )
	ROM_LOAD( "l_4r_b.bin",     0x1000, 0x0800, CRC(feaa59ee) SHA1(ecf95db5a20098804fc8bd59232c66e2e0ed3db4) )
	ROM_LOAD( "l_4s_b.bin",     0x1800, 0x0800, CRC(20f2ef7e) SHA1(3bc482a38bf579033f50082748ee95205b0f673d) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "rainbow_c.2k",   0x0000, 0x0100, CRC(c0dce2f5) SHA1(d2195886f509359ac483fd6c96a0477eef514929) )
	ROM_LOAD( "rainbow_c.2j",   0x0100, 0x0100, CRC(03c3153f) SHA1(611267c0a205c9fe258451b7b5545c7a3d2fb541) )
	ROM_LOAD( "rainbow_v.5e",   0x0200, 0x0100, CRC(d9f3005a) SHA1(c4f09f27f5c78d95d31e6af1b8a977b86bbab9a4) )
ROM_END

ROM_START( dkchrmx )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "c_5et_g.bin",    0x0000, 0x1000, CRC(ba70b88b) SHA1(d76ebecfea1af098d843ee7e578e480cd658ac1a) )
	ROM_LOAD( "c_5ct_g.bin",    0x1000, 0x1000, CRC(5ec461ec) SHA1(acb11a8fbdbb3ab46068385fe465f681e3c824bd) )
	ROM_LOAD( "c_5bt_g.bin",    0x2000, 0x1000, CRC(1c97d324) SHA1(c7966261f3a1d3296927e0b6ee1c58039fc53c1f) )
	ROM_LOAD( "c_5at_g.bin",    0x3000, 0x1000, CRC(b9005ac0) SHA1(3fe3599f6fa7c496f782053ddf7bacb453d197c4) )

	ROM_REGION( 0x10000, "braze", 0 )
	ROM_LOAD( "dkchrmx.bin",    0x0000, 0x10000, CRC(e5273cee) SHA1(c440d47e7e3ca356ae1d748cc673393efb2b6c4a) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "v_5h_b.ch",      0x0000, 0x0800, CRC(0b92cc7a) SHA1(cd217c2b45a86744c2fc7df8a3b624489e07f01f) )
	ROM_LOAD( "v_3pt.ch",       0x0800, 0x0800, CRC(6a04f93f) SHA1(b78342f89186c3d2b83fff6fd208afaba4584a5c) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "l_4m_b.ch",      0x0000, 0x0800, CRC(c6ddc85f) SHA1(4f19be0904460ec8494bad13b3b55292889e7400) )
	ROM_LOAD( "l_4n_b.ch",      0x0800, 0x0800, CRC(2cd9cfdf) SHA1(fd9b0b75084661441680188ef3faf233579ceeb7) )
	ROM_LOAD( "l_4r_b.ch",      0x1000, 0x0800, CRC(c1ea6688) SHA1(3509bb96d2da1f364d0cb4c60636933cdd42f6e3) )
	ROM_LOAD( "l_4s_b.ch",      0x1800, 0x0800, CRC(9473d658) SHA1(2c5acf47c0ab8bd2e863e9bdea018d17ac4c96c8) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "c-2k.ch",        0x0000, 0x0100, CRC(c6cee97e) SHA1(6590b6815a0cb19b800bce0f504494217977ae44) )
	ROM_LOAD( "c-2j.ch",        0x0100, 0x0100, CRC(1f64ac3d) SHA1(0591495a75a301772856c121f34299da4f9df341) )
	ROM_LOAD( "v-5e.ch",        0x0200, 0x0100, CRC(5a8ca805) SHA1(8e711af73ddb20ed62a9a8b53f1150feab1dc051) )
ROM_END

ROM_START( dkchrte )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "c_5et_g.bin",    0x0000, 0x1000, CRC(ba70b88b) SHA1(d76ebecfea1af098d843ee7e578e480cd658ac1a) )
	ROM_LOAD( "c_5ct_g.bin",    0x1000, 0x1000, CRC(5ec461ec) SHA1(acb11a8fbdbb3ab46068385fe465f681e3c824bd) )
	ROM_LOAD( "c_5bt_g.bin",    0x2000, 0x1000, CRC(1c97d324) SHA1(c7966261f3a1d3296927e0b6ee1c58039fc53c1f) )
	ROM_LOAD( "c_5at_g.bin",    0x3000, 0x1000, CRC(b9005ac0) SHA1(3fe3599f6fa7c496f782053ddf7bacb453d197c4) )

	ROM_REGION( 0x10000, "braze", 0 )
	ROM_LOAD( "dkchrte.bin",    0x0000, 0x10000, CRC(3d6b05f6) SHA1(2fcfbe81f00ee8c672edaf869b28620fb2ab2944) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "dkchrte.5h",     0x0000, 0x0800, CRC(0bdb6d28) SHA1(f95394d1b9a18dbda25af0e56f3f7c7ad3d37799) )
	ROM_LOAD( "dkchrte.3pt",    0x0800, 0x0800, CRC(6bb0affb) SHA1(ca72ee4435f34c656963f712d5dee5ba865e0c85) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "dkchrte.4m",     0x0000, 0x0800, CRC(3282f0a1) SHA1(c8034fdc3acc013e3f497c14f26a3800e507dee8) )
	ROM_LOAD( "dkchrte.4n",     0x0800, 0x0800, CRC(89ebf388) SHA1(c567ee4ac9e5bcf32d12eef7319dc30ca2d093d0) )
	ROM_LOAD( "dkchrte.4r",     0x1000, 0x0800, CRC(fe8b84a8) SHA1(0a43cadbda6e91ddf937561622c63faa0ff7fab6) )
	ROM_LOAD( "dkchrte.4s",     0x1800, 0x0800, CRC(3b18ae70) SHA1(5a4b485a379d8282dab033dc77fa361f6fef5e51) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "c-2k.ch",        0x0000, 0x0100, CRC(c6cee97e) SHA1(6590b6815a0cb19b800bce0f504494217977ae44) )
	ROM_LOAD( "c-2j.ch",        0x0100, 0x0100, CRC(1f64ac3d) SHA1(0591495a75a301772856c121f34299da4f9df341) )
	ROM_LOAD( "v-5e.ch",        0x0200, 0x0100, CRC(5a8ca805) SHA1(8e711af73ddb20ed62a9a8b53f1150feab1dc051) )
ROM_END

ROM_START( dkspkyrmx )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "c_5et_g.bin",    0x0000, 0x1000, CRC(ba70b88b) SHA1(d76ebecfea1af098d843ee7e578e480cd658ac1a) )
	ROM_LOAD( "c_5ct_g.bin",    0x1000, 0x1000, CRC(5ec461ec) SHA1(acb11a8fbdbb3ab46068385fe465f681e3c824bd) )
	ROM_LOAD( "c_5bt_g.bin",    0x2000, 0x1000, CRC(1c97d324) SHA1(c7966261f3a1d3296927e0b6ee1c58039fc53c1f) )
	ROM_LOAD( "c_5at_g.bin",    0x3000, 0x1000, CRC(b9005ac0) SHA1(3fe3599f6fa7c496f782053ddf7bacb453d197c4) )

	ROM_REGION( 0x10000, "braze", 0 )
	ROM_LOAD( "dkspkyrmx.bin",  0x0000, 0x8000, CRC(e68c6bfc) SHA1(e68442aadf89d2a783083d0648c95252b6a7ede1) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "v_5h_b.sp",      0x0000, 0x0800, CRC(b70b0904) SHA1(ee06b0fd5d6a212e688ef83d04f5529b55cd1245) )
	ROM_LOAD( "v_3pt.sp",       0x0800, 0x0800, CRC(be8c92c3) SHA1(33b2740cda696dc24f47b33b6427438b31e38125) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "l_4m_b.sp",      0x0000, 0x0800, CRC(1d0b3b77) SHA1(4f74cf19e6f74a5686482fde766a5ad45a86af68) )
	ROM_LOAD( "l_4n_b.sp",      0x0800, 0x0800, CRC(cd717e7c) SHA1(e813c3714abf737e6a9f8d6ec87ec0de85306dc1) )
	ROM_LOAD( "l_4r_b.sp",      0x1000, 0x0800, CRC(d019732b) SHA1(44f695103579b1583942627434d6f5801f504cb5) )
	ROM_LOAD( "l_4s_b.sp",      0x1800, 0x0800, CRC(04272273) SHA1(4d66296f228cfc07f12ab7cfd1b7af99bd54e574) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "c-2k.sp",        0x0000, 0x0100, CRC(a837a227) SHA1(f5ebbedbc86153864b1bcfa26ab35eeb8856c7e0) )
	ROM_LOAD( "c-2j.sp",        0x0100, 0x0100, CRC(244a89f9) SHA1(4a59233a4bad4c941aa3aad85d895e8c04d34436) )
	ROM_LOAD( "v-5e.sp",        0x0200, 0x0100, CRC(c70b6f9b) SHA1(e9f465de5e990478e96be1501cb8c5fc16b3c86e) )
ROM_END

ROM_START( dkongte )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "c_5et_g.bin",  0x0000, 0x1000, CRC(ba70b88b) SHA1(d76ebecfea1af098d843ee7e578e480cd658ac1a) )
	ROM_LOAD( "c_5ct_g.bin",  0x1000, 0x1000, CRC(5ec461ec) SHA1(acb11a8fbdbb3ab46068385fe465f681e3c824bd) )
	ROM_LOAD( "c_5bt_g.bin",  0x2000, 0x1000, CRC(1c97d324) SHA1(c7966261f3a1d3296927e0b6ee1c58039fc53c1f) )
	ROM_LOAD( "c_5at_g.bin",  0x3000, 0x1000, CRC(b9005ac0) SHA1(3fe3599f6fa7c496f782053ddf7bacb453d197c4) )

	ROM_REGION( 0x10000, "braze", 0 )
	ROM_LOAD( "d2k11.te",     0x00000, 0x10000, CRC(55fc9018) SHA1(48a53e9504c1d4b37ed79e06f59da5e96c1a3524) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",   0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(               0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",   0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "v_5h_b.bin",   0x0000, 0x0800, CRC(12c8c95d) SHA1(a57ff5a231c45252a63b354137c920a1379b70a3) )
	ROM_LOAD( "v_3pt.bin",    0x0800, 0x0800, CRC(15e9c5e9) SHA1(976eb1e18c74018193a35aa86cff482ebfc5cc4e) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "l_4m_b.bin",   0x0000, 0x0800, CRC(59f8054d) SHA1(793dba9bf5a5fe76328acdfb90815c243d2a65f1) )
	ROM_LOAD( "l_4n_b.bin",   0x0800, 0x0800, CRC(672e4714) SHA1(92e5d379f4838ac1fa44d448ce7d142dae42102f) )
	ROM_LOAD( "l_4r_b.bin",   0x1000, 0x0800, CRC(feaa59ee) SHA1(ecf95db5a20098804fc8bd59232c66e2e0ed3db4) )
	ROM_LOAD( "l_4s_b.bin",   0x1800, 0x0800, CRC(20f2ef7e) SHA1(3bc482a38bf579033f50082748ee95205b0f673d) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "c-2k.bpr",     0x0000, 0x0100, CRC(e273ede5) SHA1(b50ec9e1837c00c20fb2a4369ec7dd0358321127) )
	ROM_LOAD( "c-2j.bpr",     0x0100, 0x0100, CRC(d6412358) SHA1(f9c872da2fe8e800574ae3bf483fb3ccacc92eb3) )
	ROM_LOAD( "v-5e.bpr",     0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dkspkyte )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "c_5et_g.bin",  0x0000, 0x1000, CRC(ba70b88b) SHA1(d76ebecfea1af098d843ee7e578e480cd658ac1a) )
	ROM_LOAD( "c_5ct_g.bin",  0x1000, 0x1000, CRC(5ec461ec) SHA1(acb11a8fbdbb3ab46068385fe465f681e3c824bd) )
	ROM_LOAD( "c_5bt_g.bin",  0x2000, 0x1000, CRC(1c97d324) SHA1(c7966261f3a1d3296927e0b6ee1c58039fc53c1f) )
	ROM_LOAD( "c_5at_g.bin",  0x3000, 0x1000, CRC(b9005ac0) SHA1(3fe3599f6fa7c496f782053ddf7bacb453d197c4) )

	ROM_REGION( 0x10000, "braze", 0 )
	ROM_LOAD( "d2k11.spte",   0x00000, 0x10000, CRC(2bb8d91e) SHA1(1b5246944c715ffd190addd5003bdd27577fae2e) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",   0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(               0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",   0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "v_5h_b.spte",  0x0000, 0x0800, CRC(ebc5d9cc) SHA1(f4b0bcf3d48dd2d92d7bbb25c711ac0820c30142) )
	ROM_LOAD( "v_3pt.spte",   0x0800, 0x0800, CRC(9d881b5f) SHA1(42c8070250a356db452e4d008875d20b61082194) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "l_4m_b.sp",    0x0000, 0x0800, CRC(1d0b3b77) SHA1(4f74cf19e6f74a5686482fde766a5ad45a86af68) )
	ROM_LOAD( "l_4n_b.sp",    0x0800, 0x0800, CRC(cd717e7c) SHA1(e813c3714abf737e6a9f8d6ec87ec0de85306dc1) )
	ROM_LOAD( "l_4r_b.sp",    0x1000, 0x0800, CRC(d019732b) SHA1(44f695103579b1583942627434d6f5801f504cb5) )
	ROM_LOAD( "l_4s_b.sp",    0x1800, 0x0800, CRC(04272273) SHA1(4d66296f228cfc07f12ab7cfd1b7af99bd54e574) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "c-2k.sp",      0x0000, 0x0100, CRC(a837a227) SHA1(f5ebbedbc86153864b1bcfa26ab35eeb8856c7e0) )
	ROM_LOAD( "c-2j.sp",      0x0100, 0x0100, CRC(244a89f9) SHA1(4a59233a4bad4c941aa3aad85d895e8c04d34436) )
	ROM_LOAD( "v-5e.sp",      0x0200, 0x0100, CRC(c70b6f9b) SHA1(e9f465de5e990478e96be1501cb8c5fc16b3c86e) )
ROM_END

ROM_START( dktrainer )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkt.5et",        0x0000, 0x1000, CRC(7ed5a945) SHA1(27ea2b9ca8e03a660943b043a2880c95a4f92de8) )
	ROM_LOAD( "dkt.5ct",        0x1000, 0x1000, CRC(98e2caa8) SHA1(5289f2268bac39bd04da8b9b94e25e55e4ea8e04) )
	ROM_LOAD( "dkt.5bt",        0x2000, 0x1000, CRC(098a840a) SHA1(05ea657be2de863fb8a42bf1e173a6a80fb16cc7) )
	ROM_LOAD( "dkt.5at",        0x3000, 0x1000, CRC(dd092591) SHA1(36455e5a689a926b79be79e38d96ad8fe2ce7417) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "v_5h_b.bin",     0x0000, 0x0800, CRC(12c8c95d) SHA1(a57ff5a231c45252a63b354137c920a1379b70a3) )
	ROM_LOAD( "v_3pt.bin",      0x0800, 0x0800, CRC(15e9c5e9) SHA1(976eb1e18c74018193a35aa86cff482ebfc5cc4e) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "l_4m_b.bin",     0x0000, 0x0800, CRC(59f8054d) SHA1(793dba9bf5a5fe76328acdfb90815c243d2a65f1) )
	ROM_LOAD( "l_4n_b.bin",     0x0800, 0x0800, CRC(672e4714) SHA1(92e5d379f4838ac1fa44d448ce7d142dae42102f) )
	ROM_LOAD( "l_4r_b.bin",     0x1000, 0x0800, CRC(feaa59ee) SHA1(ecf95db5a20098804fc8bd59232c66e2e0ed3db4) )
	ROM_LOAD( "l_4s_b.bin",     0x1800, 0x0800, CRC(20f2ef7e) SHA1(3bc482a38bf579033f50082748ee95205b0f673d) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "c-2k.bpr",       0x0000, 0x0100, CRC(e273ede5) SHA1(b50ec9e1837c00c20fb2a4369ec7dd0358321127) )
	ROM_LOAD( "c-2j.bpr",       0x0100, 0x0100, CRC(d6412358) SHA1(f9c872da2fe8e800574ae3bf483fb3ccacc92eb3) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dkpace )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkp.5et",        0x0000, 0x1000, CRC(e05563d5) SHA1(db17bf866e223a5b57e3fdd23f79f1f8ca67f697) )
	ROM_LOAD( "dkp.5ct",        0x1000, 0x1000, CRC(88aa1ddf) SHA1(d1582ba10cf15b24286524fa494279a4d25adfbb) )
	ROM_LOAD( "dkp.5bt",        0x2000, 0x1000, CRC(8ee0b1d2) SHA1(7cae6b1b3143fbf1c2ad0cbfa7855eb1c9519fde) )
	ROM_LOAD( "dkp.5at",        0x3000, 0x1000, CRC(0bc9c8db) SHA1(8e51b4d6905d8321c9d29e51d830c8554a94f664) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "v_5h_b.bin",     0x0000, 0x0800, CRC(12c8c95d) SHA1(a57ff5a231c45252a63b354137c920a1379b70a3) )
	ROM_LOAD( "v_3pt.bin",      0x0800, 0x0800, CRC(15e9c5e9) SHA1(976eb1e18c74018193a35aa86cff482ebfc5cc4e) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "l_4m_b.bin",     0x0000, 0x0800, CRC(59f8054d) SHA1(793dba9bf5a5fe76328acdfb90815c243d2a65f1) )
	ROM_LOAD( "l_4n_b.bin",     0x0800, 0x0800, CRC(672e4714) SHA1(92e5d379f4838ac1fa44d448ce7d142dae42102f) )
	ROM_LOAD( "l_4r_b.bin",     0x1000, 0x0800, CRC(feaa59ee) SHA1(ecf95db5a20098804fc8bd59232c66e2e0ed3db4) )
	ROM_LOAD( "l_4s_b.bin",     0x1800, 0x0800, CRC(20f2ef7e) SHA1(3bc482a38bf579033f50082748ee95205b0f673d) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "c-2k.bpr",       0x0000, 0x0100, CRC(e273ede5) SHA1(b50ec9e1837c00c20fb2a4369ec7dd0358321127) )
	ROM_LOAD( "c-2j.bpr",       0x0100, 0x0100, CRC(d6412358) SHA1(f9c872da2fe8e800574ae3bf483fb3ccacc92eb3) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dkongbcc )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkbcc.5et",      0x0000, 0x1000, CRC(eec71586) SHA1(8c9c05c919265d6b930e5088e869c4b44264ded4) )
	ROM_LOAD( "dkbcc.5ct",      0x1000, 0x1000, CRC(49200edb) SHA1(e40a19700196dc7b2ae766cbef51867856c986aa) )
	ROM_LOAD( "dkbcc.5bt",      0x2000, 0x1000, CRC(56f7c409) SHA1(265817ce17951d49b95a2361c5cc3032620aae96) )
	ROM_LOAD( "dkbcc.5at",      0x3000, 0x1000, CRC(03b56372) SHA1(fea19bb4c46c88c26943ccd910b560cecd5dc44c) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "v_5h_b.bin",     0x0000, 0x0800, CRC(12c8c95d) SHA1(a57ff5a231c45252a63b354137c920a1379b70a3) )
	ROM_LOAD( "v_3pt.bin",      0x0800, 0x0800, CRC(15e9c5e9) SHA1(976eb1e18c74018193a35aa86cff482ebfc5cc4e) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "l_4m_b.bin",     0x0000, 0x0800, CRC(59f8054d) SHA1(793dba9bf5a5fe76328acdfb90815c243d2a65f1) )
	ROM_LOAD( "l_4n_b.bin",     0x0800, 0x0800, CRC(672e4714) SHA1(92e5d379f4838ac1fa44d448ce7d142dae42102f) )
	ROM_LOAD( "l_4r_b.bin",     0x1000, 0x0800, CRC(feaa59ee) SHA1(ecf95db5a20098804fc8bd59232c66e2e0ed3db4) )
	ROM_LOAD( "l_4s_b.bin",     0x1800, 0x0800, CRC(20f2ef7e) SHA1(3bc482a38bf579033f50082748ee95205b0f673d) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "c-2k.bpr",       0x0000, 0x0100, CRC(e273ede5) SHA1(b50ec9e1837c00c20fb2a4369ec7dd0358321127) )
	ROM_LOAD( "c-2j.bpr",       0x0100, 0x0100, CRC(d6412358) SHA1(f9c872da2fe8e800574ae3bf483fb3ccacc92eb3) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dkcbarrel )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkcbarrel.5et",  0x0000, 0x1000, CRC(78e37c41) SHA1(1a30f11d6c49f168da9ccb7bda44e2d001544177) )
	ROM_LOAD( "dkcbarrel.5ct",  0x1000, 0x1000, CRC(a46cbb85) SHA1(f19a397b0556676dbc854b3072a0f48660759d8a) )
	ROM_LOAD( "dkcbarrel.5bt",  0x2000, 0x1000, CRC(07da5b15) SHA1(14f0a510783ce618c1acdcef35837f0dc3fbd370) )
	ROM_LOAD( "dkcbarrel.5at",  0x3000, 0x1000, CRC(515e0639) SHA1(c556cc9aa67cb36fa3aad6b4ad4d5e726b35378a) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "v_5h_b.bin",     0x0000, 0x0800, CRC(12c8c95d) SHA1(a57ff5a231c45252a63b354137c920a1379b70a3) )
	ROM_LOAD( "v_3pt.bin",      0x0800, 0x0800, CRC(15e9c5e9) SHA1(976eb1e18c74018193a35aa86cff482ebfc5cc4e) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "l_4m_b.bin",     0x0000, 0x0800, CRC(59f8054d) SHA1(793dba9bf5a5fe76328acdfb90815c243d2a65f1) )
	ROM_LOAD( "l_4n_b.bin",     0x0800, 0x0800, CRC(672e4714) SHA1(92e5d379f4838ac1fa44d448ce7d142dae42102f) )
	ROM_LOAD( "l_4r_b.bin",     0x1000, 0x0800, CRC(feaa59ee) SHA1(ecf95db5a20098804fc8bd59232c66e2e0ed3db4) )
	ROM_LOAD( "l_4s_b.bin",     0x1800, 0x0800, CRC(20f2ef7e) SHA1(3bc482a38bf579033f50082748ee95205b0f673d) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "c-2k.bpr",       0x0000, 0x0100, CRC(e273ede5) SHA1(b50ec9e1837c00c20fb2a4369ec7dd0358321127) )
	ROM_LOAD( "c-2j.bpr",       0x0100, 0x0100, CRC(d6412358) SHA1(f9c872da2fe8e800574ae3bf483fb3ccacc92eb3) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dkfreerun )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkfreerun.5et",  0x0000, 0x1000, CRC(2b85ddf0) SHA1(61a0cb413e4ec794ee5997f7b67f36645f9af03b) )
	ROM_LOAD( "dkfreerun.5ct",  0x1000, 0x1000, CRC(ef7e15d7) SHA1(22a8c25eed51b7fc4bbcc09ae87fc24baf688983) )
	ROM_LOAD( "dkfreerun.5bt",  0x2000, 0x1000, CRC(cb390d7c) SHA1(13dc382a543d216772858451be749534337c5163) )
	ROM_LOAD( "dkfreerun.5at",  0x3000, 0x1000, CRC(76fb86ba) SHA1(9934df182b54fdc7f5e551eb07e236550308ec73) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "v_5h_b.bin",     0x0000, 0x0800, CRC(12c8c95d) SHA1(a57ff5a231c45252a63b354137c920a1379b70a3) )
	ROM_LOAD( "v_3pt.bin",      0x0800, 0x0800, CRC(15e9c5e9) SHA1(976eb1e18c74018193a35aa86cff482ebfc5cc4e) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "l_4m_b.bin",     0x0000, 0x0800, CRC(59f8054d) SHA1(793dba9bf5a5fe76328acdfb90815c243d2a65f1) )
	ROM_LOAD( "l_4n_b.bin",     0x0800, 0x0800, CRC(672e4714) SHA1(92e5d379f4838ac1fa44d448ce7d142dae42102f) )
	ROM_LOAD( "l_4r_b.bin",     0x1000, 0x0800, CRC(feaa59ee) SHA1(ecf95db5a20098804fc8bd59232c66e2e0ed3db4) )
	ROM_LOAD( "l_4s_b.bin",     0x1800, 0x0800, CRC(20f2ef7e) SHA1(3bc482a38bf579033f50082748ee95205b0f673d) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "c-2k.bpr",       0x0000, 0x0100, CRC(e273ede5) SHA1(b50ec9e1837c00c20fb2a4369ec7dd0358321127) )
	ROM_LOAD( "c-2j.bpr",       0x0100, 0x0100, CRC(d6412358) SHA1(f9c872da2fe8e800574ae3bf483fb3ccacc92eb3) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dkongrev )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkongrev.5et",   0x0000, 0x1000, CRC(ee02057e) SHA1(4d035ed48d8ff6f602cc8892033c28a784242787) )
	ROM_LOAD( "dkongrev.5ct",   0x1000, 0x1000, CRC(e6fabd0f) SHA1(53782655b5cbdeb78abff9a5194467c82ff8f48e) )
	ROM_LOAD( "dkongrev.5bt",   0x2000, 0x1000, CRC(31c5bea3) SHA1(d92c86ef55c09d9e038551f8c69c7777fd71c11a) )
	ROM_LOAD( "dkongrev.5at",   0x3000, 0x1000, CRC(c7d04ef3) SHA1(33224c6c869a898212a4b3b5f56bd80b3dbd4bac) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "v_5h_b.bin",     0x0000, 0x0800, CRC(12c8c95d) SHA1(a57ff5a231c45252a63b354137c920a1379b70a3) )
	ROM_LOAD( "v_3pt.bin",      0x0800, 0x0800, CRC(15e9c5e9) SHA1(976eb1e18c74018193a35aa86cff482ebfc5cc4e) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "l_4m_b.bin",     0x0000, 0x0800, CRC(59f8054d) SHA1(793dba9bf5a5fe76328acdfb90815c243d2a65f1) )
	ROM_LOAD( "l_4n_b.bin",     0x0800, 0x0800, CRC(672e4714) SHA1(92e5d379f4838ac1fa44d448ce7d142dae42102f) )
	ROM_LOAD( "l_4r_b.bin",     0x1000, 0x0800, CRC(feaa59ee) SHA1(ecf95db5a20098804fc8bd59232c66e2e0ed3db4) )
	ROM_LOAD( "l_4s_b.bin",     0x1800, 0x0800, CRC(20f2ef7e) SHA1(3bc482a38bf579033f50082748ee95205b0f673d) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "c-2k.bpr",       0x0000, 0x0100, CRC(e273ede5) SHA1(b50ec9e1837c00c20fb2a4369ec7dd0358321127) )
	ROM_LOAD( "c-2j.bpr",       0x0100, 0x0100, CRC(d6412358) SHA1(f9c872da2fe8e800574ae3bf483fb3ccacc92eb3) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dkongrnd0 )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkongrnd0.5at",  0x3000, 0x1000, CRC(71356cfe) SHA1(8f426c8d80523e3dcd4cdf3dec544e09eda5d980) )
	ROM_LOAD( "dkongchm.5bt",   0x2000, 0x1000, CRC(fce41e06) SHA1(fdab4f37f914d56a28092592f9cbb3d2502c925e) )
	ROM_LOAD( "dkongrnd0.5ct",  0x1000, 0x1000, CRC(e25eccf8) SHA1(9fe57daf894d78f07092262682a78b22360d8b57) )
	ROM_LOAD( "dkongrnd0.5et",  0x0000, 0x1000, CRC(c450e88c) SHA1(d4de8bf551e8416329771a7c68c4eb79b4ea1bb0) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "v_3pt.rnd",      0x0800, 0x0800, CRC(49d408cd) SHA1(562751627dc050a13552f401221806b30797afd4) )
	ROM_LOAD( "v_5h_b.rnd",     0x0000, 0x0800, CRC(17ef76ad) SHA1(ca58ae7de241417f05a510b459db16f1f2120cd0) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "l_4m_b.bin",     0x0000, 0x0800, CRC(59f8054d) SHA1(793dba9bf5a5fe76328acdfb90815c243d2a65f1) )
	ROM_LOAD( "l_4n_b.bin",     0x0800, 0x0800, CRC(672e4714) SHA1(92e5d379f4838ac1fa44d448ce7d142dae42102f) )
	ROM_LOAD( "l_4r_b.bin",     0x1000, 0x0800, CRC(feaa59ee) SHA1(ecf95db5a20098804fc8bd59232c66e2e0ed3db4) )
	ROM_LOAD( "l_4s_b.bin",     0x1800, 0x0800, CRC(20f2ef7e) SHA1(3bc482a38bf579033f50082748ee95205b0f673d) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "c-2j.bpr",       0x0100, 0x0100, CRC(d6412358) SHA1(f9c872da2fe8e800574ae3bf483fb3ccacc92eb3) )
	ROM_LOAD( "c-2k.bpr",       0x0000, 0x0100, CRC(e273ede5) SHA1(b50ec9e1837c00c20fb2a4369ec7dd0358321127) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dkongrnd ) // some sound issues
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkongrnd.5et",   0x0000, 0x1000, CRC(fc29f234) SHA1(6e55ca043699ed12b08cd0658bdd98a195c89380) )
	ROM_LOAD( "dkongrnd.5ct",   0x1000, 0x1000, CRC(49e16508) SHA1(b67d5b94685a7193ae674f2a78f69bf7d678d707) )
	ROM_LOAD( "dkongchm.5bt",   0x2000, 0x1000, CRC(fce41e06) SHA1(fdab4f37f914d56a28092592f9cbb3d2502c925e) )
	ROM_LOAD( "dkongrnd.5at",   0x3000, 0x1000, CRC(86723e5d) SHA1(88e8b4209eaad14902cb2aaf9886727007e9b0ed) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "v_5h_b.rnd",     0x0000, 0x0800, CRC(17ef76ad) SHA1(ca58ae7de241417f05a510b459db16f1f2120cd0) )
	ROM_LOAD( "v_3pt.rnd",      0x0800, 0x0800, CRC(49d408cd) SHA1(562751627dc050a13552f401221806b30797afd4) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "l_4m_b.bin",     0x0000, 0x0800, CRC(59f8054d) SHA1(793dba9bf5a5fe76328acdfb90815c243d2a65f1) )
	ROM_LOAD( "l_4n_b.bin",     0x0800, 0x0800, CRC(672e4714) SHA1(92e5d379f4838ac1fa44d448ce7d142dae42102f) )
	ROM_LOAD( "l_4r_b.bin",     0x1000, 0x0800, CRC(feaa59ee) SHA1(ecf95db5a20098804fc8bd59232c66e2e0ed3db4) )
	ROM_LOAD( "l_4s_b.bin",     0x1800, 0x0800, CRC(20f2ef7e) SHA1(3bc482a38bf579033f50082748ee95205b0f673d) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "c-2k.bpr",       0x0000, 0x0100, CRC(e273ede5) SHA1(b50ec9e1837c00c20fb2a4369ec7dd0358321127) )
	ROM_LOAD( "c-2j.bpr",       0x0100, 0x0100, CRC(d6412358) SHA1(f9c872da2fe8e800574ae3bf483fb3ccacc92eb3) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dkongklc )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkongchm.5et",   0x0000, 0x1000, CRC(26890d72) SHA1(3d32d8d892ea7256882528f07236db4c0c225220) )
	ROM_LOAD( "dkongchm.5ct",   0x1000, 0x1000, CRC(d5965c23) SHA1(266f8864b3e27cb4327e17eaf122e21b3b8909b8) )
	ROM_LOAD( "dkongchm.5bt",   0x2000, 0x1000, CRC(fce41e06) SHA1(fdab4f37f914d56a28092592f9cbb3d2502c925e) )
	ROM_LOAD( "dkongchm.5at",   0x3000, 0x1000, CRC(c48a4053) SHA1(a0a4282e75b6e44e2ce9162329a568c5d1676944) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "v_5h_b.chm",     0x0000, 0x0800, CRC(a7a3772b) SHA1(09cff96e166794154aca8f6899a08d1637827cc0) )
	ROM_LOAD( "v_3pt.chm",      0x0800, 0x0800, CRC(72b0b861) SHA1(6517b7a4f8d4f9db483ea2b72ebb9e45cebb4cd5) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "l_4m_b.bin",     0x0000, 0x0800, CRC(59f8054d) SHA1(793dba9bf5a5fe76328acdfb90815c243d2a65f1) )
	ROM_LOAD( "l_4n_b.bin",     0x0800, 0x0800, CRC(672e4714) SHA1(92e5d379f4838ac1fa44d448ce7d142dae42102f) )
	ROM_LOAD( "l_4r_b.bin",     0x1000, 0x0800, CRC(feaa59ee) SHA1(ecf95db5a20098804fc8bd59232c66e2e0ed3db4) )
	ROM_LOAD( "l_4s_b.bin",     0x1800, 0x0800, CRC(20f2ef7e) SHA1(3bc482a38bf579033f50082748ee95205b0f673d) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "c-2k.bpr",       0x0000, 0x0100, CRC(e273ede5) SHA1(b50ec9e1837c00c20fb2a4369ec7dd0358321127) )
	ROM_LOAD( "c-2j.bpr",       0x0100, 0x0100, CRC(d6412358) SHA1(f9c872da2fe8e800574ae3bf483fb3ccacc92eb3) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dkongce )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkongchm.5et",   0x0000, 0x1000, CRC(26890d72) SHA1(3d32d8d892ea7256882528f07236db4c0c225220) )
	ROM_LOAD( "dkongchm.5ct",   0x1000, 0x1000, CRC(d5965c23) SHA1(266f8864b3e27cb4327e17eaf122e21b3b8909b8) )
	ROM_LOAD( "dkongchm.5bt",   0x2000, 0x1000, CRC(fce41e06) SHA1(fdab4f37f914d56a28092592f9cbb3d2502c925e) )
	ROM_LOAD( "dkongchm1.5at",  0x3000, 0x1000, CRC(458ff9b9) SHA1(81c5874fd03fbd32f9c83ca5534f66a41ffc1fe4) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "v_5h_b.bin",     0x0000, 0x0800, CRC(12c8c95d) SHA1(a57ff5a231c45252a63b354137c920a1379b70a3) )
	ROM_LOAD( "v_3pt.bin",      0x0800, 0x0800, CRC(15e9c5e9) SHA1(976eb1e18c74018193a35aa86cff482ebfc5cc4e) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "l_4m_b.bin",     0x0000, 0x0800, CRC(59f8054d) SHA1(793dba9bf5a5fe76328acdfb90815c243d2a65f1) )
	ROM_LOAD( "l_4n_b.bin",     0x0800, 0x0800, CRC(672e4714) SHA1(92e5d379f4838ac1fa44d448ce7d142dae42102f) )
	ROM_LOAD( "l_4r_b.bin",     0x1000, 0x0800, CRC(feaa59ee) SHA1(ecf95db5a20098804fc8bd59232c66e2e0ed3db4) )
	ROM_LOAD( "l_4s_b.bin",     0x1800, 0x0800, CRC(20f2ef7e) SHA1(3bc482a38bf579033f50082748ee95205b0f673d) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "c-2k.bpr",       0x0000, 0x0100, CRC(e273ede5) SHA1(b50ec9e1837c00c20fb2a4369ec7dd0358321127) )
	ROM_LOAD( "c-2j.bpr",       0x0100, 0x0100, CRC(d6412358) SHA1(f9c872da2fe8e800574ae3bf483fb3ccacc92eb3) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dkongst )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkongst.5et",    0x0000, 0x1000, CRC(8fb6e908) SHA1(f361699ef3ba76e3734dfe31dedeb4363ac7f837) )
	ROM_LOAD( "dkongst.5ct",    0x1000, 0x1000, CRC(c9d766ea) SHA1(0e4d6fc04e88c4622a63fccf49cdfa2e008210cf) )
	ROM_LOAD( "dkongst.5bt",    0x2000, 0x1000, CRC(aef88ff5) SHA1(621300c9a43c000958aa8a11e7ff0cf2d14a2d32) )
	ROM_LOAD( "dkongst.5at",    0x3000, 0x1000, CRC(5cf3774b) SHA1(7061fb739b03d947a320a2ce3a11598ef520d586) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "v_5h_b.bin",     0x0000, 0x0800, CRC(12c8c95d) SHA1(a57ff5a231c45252a63b354137c920a1379b70a3) )
	ROM_LOAD( "v_3pt.bin",      0x0800, 0x0800, CRC(15e9c5e9) SHA1(976eb1e18c74018193a35aa86cff482ebfc5cc4e) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "l_4m_b.bin",     0x0000, 0x0800, CRC(59f8054d) SHA1(793dba9bf5a5fe76328acdfb90815c243d2a65f1) )
	ROM_LOAD( "l_4n_b.bin",     0x0800, 0x0800, CRC(672e4714) SHA1(92e5d379f4838ac1fa44d448ce7d142dae42102f) )
	ROM_LOAD( "l_4r_b.bin",     0x1000, 0x0800, CRC(feaa59ee) SHA1(ecf95db5a20098804fc8bd59232c66e2e0ed3db4) )
	ROM_LOAD( "l_4s_b.bin",     0x1800, 0x0800, CRC(20f2ef7e) SHA1(3bc482a38bf579033f50082748ee95205b0f673d) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "c-2k.bpr",       0x0000, 0x0100, CRC(e273ede5) SHA1(b50ec9e1837c00c20fb2a4369ec7dd0358321127) )
	ROM_LOAD( "c-2j.bpr",       0x0100, 0x0100, CRC(d6412358) SHA1(f9c872da2fe8e800574ae3bf483fb3ccacc92eb3) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dkongst2 )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkongst2.5et",   0x0000, 0x1000, CRC(21ddc6cc) SHA1(4473f7656462bc3bc319d0f01c1742003d27cbb0) )
	ROM_LOAD( "dkongst2.5ct",   0x1000, 0x1000, CRC(fa14da2c) SHA1(3011062ee771f621f359f0fa68bf85ccb76e2989) )
	ROM_LOAD( "dkongst2.5bt",   0x2000, 0x1000, CRC(32a8f924) SHA1(540de355eab7ca7068e655de72dfbdb4015098ee) )
	ROM_LOAD( "dkongst2.5at",   0x3000, 0x0f00, CRC(27b9c90d) SHA1(5b5e92d35a0b487cd1b618ddded80a9e33ee2ca9) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "v_5h_b.bin",     0x0000, 0x0800, CRC(12c8c95d) SHA1(a57ff5a231c45252a63b354137c920a1379b70a3) )
	ROM_LOAD( "v_3pt.bin",      0x0800, 0x0800, CRC(15e9c5e9) SHA1(976eb1e18c74018193a35aa86cff482ebfc5cc4e) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "l_4m_b.bin",     0x0000, 0x0800, CRC(59f8054d) SHA1(793dba9bf5a5fe76328acdfb90815c243d2a65f1) )
	ROM_LOAD( "l_4n_b.bin",     0x0800, 0x0800, CRC(672e4714) SHA1(92e5d379f4838ac1fa44d448ce7d142dae42102f) )
	ROM_LOAD( "l_4r_b.bin",     0x1000, 0x0800, CRC(feaa59ee) SHA1(ecf95db5a20098804fc8bd59232c66e2e0ed3db4) )
	ROM_LOAD( "l_4s_b.bin",     0x1800, 0x0800, CRC(20f2ef7e) SHA1(3bc482a38bf579033f50082748ee95205b0f673d) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "c-2k.bpr",       0x0000, 0x0100, CRC(e273ede5) SHA1(b50ec9e1837c00c20fb2a4369ec7dd0358321127) )
	ROM_LOAD( "c-2j.bpr",       0x0100, 0x0100, CRC(d6412358) SHA1(f9c872da2fe8e800574ae3bf483fb3ccacc92eb3) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dkongss )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkongss.5et",    0x0000, 0x1000, CRC(87c65c59) SHA1(51f3d6160f58449ff9a8a5374ced4fe5b5af86b4) )
	ROM_LOAD( "c_5ct_g.bin",    0x1000, 0x1000, CRC(5ec461ec) SHA1(acb11a8fbdbb3ab46068385fe465f681e3c824bd) )
	ROM_LOAD( "dkongss.5bt",    0x2000, 0x1000, CRC(f31c0c47) SHA1(1cd546e4e1924fedcb44894c43345fe2680d6f8a) )
	ROM_LOAD( "dkongss.5at",    0x3000, 0x1000, CRC(87d58e2e) SHA1(46c940a0fd0c15bfa6c304699bef29542aabab32) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "v_5h_b.bin",     0x0000, 0x0800, CRC(12c8c95d) SHA1(a57ff5a231c45252a63b354137c920a1379b70a3) )
	ROM_LOAD( "v_3pt.bin",      0x0800, 0x0800, CRC(15e9c5e9) SHA1(976eb1e18c74018193a35aa86cff482ebfc5cc4e) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "l_4m_b.bin",     0x0000, 0x0800, CRC(59f8054d) SHA1(793dba9bf5a5fe76328acdfb90815c243d2a65f1) )
	ROM_LOAD( "l_4n_b.bin",     0x0800, 0x0800, CRC(672e4714) SHA1(92e5d379f4838ac1fa44d448ce7d142dae42102f) )
	ROM_LOAD( "l_4r_b.bin",     0x1000, 0x0800, CRC(feaa59ee) SHA1(ecf95db5a20098804fc8bd59232c66e2e0ed3db4) )
	ROM_LOAD( "l_4s_b.bin",     0x1800, 0x0800, CRC(20f2ef7e) SHA1(3bc482a38bf579033f50082748ee95205b0f673d) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "c-2k.bpr",       0x0000, 0x0100, CRC(e273ede5) SHA1(b50ec9e1837c00c20fb2a4369ec7dd0358321127) )
	ROM_LOAD( "c-2j.bpr",       0x0100, 0x0100, CRC(d6412358) SHA1(f9c872da2fe8e800574ae3bf483fb3ccacc92eb3) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dkongotr6 )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkongotr6.5at",  0x3000, 0x1000, CRC(6d9b3599) SHA1(2858e01ee7d5625a4b62a72a3d375e033a297e81) )
	ROM_LOAD( "dkongotr6.5bt",  0x2000, 0x1000, CRC(942efe0d) SHA1(0bc648452c1f9845a527d457a78aa5b8b9218c9c) )
	ROM_LOAD( "dkongotr6.5ct",  0x1000, 0x1000, CRC(1f669217) SHA1(e9efcbf407a98ed2be44f4a35cc24fff2fbd12e9) )
	ROM_LOAD( "dkongotr6.5et",  0x0000, 0x1000, CRC(3f5e2a9b) SHA1(e84005f6ce07310e306bfc27559389ce90cf4233) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "dkongotr6.3pt",  0x0800, 0x0800, CRC(afbbd1e3) SHA1(55f06467c0aa5e99572f6083d3b7719c7e7155ae) )
	ROM_LOAD( "dkongotr6.5h",   0x0000, 0x0800, CRC(4754cb2d) SHA1(d7079408aedd5fb06fa6eb7557ce9ceb0dfd82d3) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "dkongotr6.4m",   0x0000, 0x0800, CRC(f224b2bc) SHA1(718368f6cfa41b73365e9da0705774fe41ca20bb) )
	ROM_LOAD( "dkongotr6.4n",   0x0800, 0x0800, CRC(def8bca4) SHA1(bd39b9a9fa0577fe38abf2576de2be43e792e513) )
	ROM_LOAD( "dkongotr6.4r",   0x1000, 0x0800, CRC(59e3e846) SHA1(444af5f47f7abd971a17313947500c083dc8caa1) )
	ROM_LOAD( "dkongotr6.4s",   0x1800, 0x0800, CRC(b5a2e920) SHA1(1ff2143539410b83139fccab0c799d39f61bf76c) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "c-2j.bpr",       0x0100, 0x0100, CRC(d6412358) SHA1(f9c872da2fe8e800574ae3bf483fb3ccacc92eb3) )
	ROM_LOAD( "c-2k.bpr",       0x0000, 0x0100, CRC(e273ede5) SHA1(b50ec9e1837c00c20fb2a4369ec7dd0358321127) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dkongotr7 )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkongotr7.5at",  0x3000, 0x1000, CRC(ec18bc3c) SHA1(b0ad1f15ec4b07718e20f022030878446cb5ce4a) )
	ROM_LOAD( "dkongotr7.5bt",  0x2000, 0x1000, CRC(482f4a98) SHA1(24520e5462be8f4e603dad2446c219ce2fbee805) )
	ROM_LOAD( "dkongotr6.5ct",  0x1000, 0x1000, CRC(1f669217) SHA1(e9efcbf407a98ed2be44f4a35cc24fff2fbd12e9) )
	ROM_LOAD( "dkongotr7.5et",  0x0000, 0x1000, CRC(6a52532c) SHA1(7d612b87ad85d4d533c2ce049ca67b0ed1a141fe) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "dkongotr7.3pt",  0x0800, 0x0800, CRC(bfb2c04f) SHA1(85b32c16537f53348489c6b9224822090a6b9789) )
	ROM_LOAD( "dkongotr7.5h",   0x0000, 0x0800, CRC(0d588de5) SHA1(17f133823dba09969d035907f4de154a0b859dc7) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "dkongotr6.4m",   0x0000, 0x0800, CRC(f224b2bc) SHA1(718368f6cfa41b73365e9da0705774fe41ca20bb) )
	ROM_LOAD( "dkongotr6.4n",   0x0800, 0x0800, CRC(def8bca4) SHA1(bd39b9a9fa0577fe38abf2576de2be43e792e513) )
	ROM_LOAD( "dkongotr6.4r",   0x1000, 0x0800, CRC(59e3e846) SHA1(444af5f47f7abd971a17313947500c083dc8caa1) )
	ROM_LOAD( "dkongotr6.4s",   0x1800, 0x0800, CRC(b5a2e920) SHA1(1ff2143539410b83139fccab0c799d39f61bf76c) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "c-2j.bpr",       0x0100, 0x0100, CRC(d6412358) SHA1(f9c872da2fe8e800574ae3bf483fb3ccacc92eb3) )
	ROM_LOAD( "c-2k.bpr",       0x0000, 0x0100, CRC(e273ede5) SHA1(b50ec9e1837c00c20fb2a4369ec7dd0358321127) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dkongotr8 )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkongotr8.5at",  0x3000, 0x1000, CRC(83f713d8) SHA1(f9e4e14b64e0c7f851b72e9b8ac8600429a13548) )
	ROM_LOAD( "dkongotr8.5bt",  0x2000, 0x1000, CRC(d029c495) SHA1(3fc4a883ff7028a399a3452dcacee74fa50cc3db) )
	ROM_LOAD( "dkongotr8.5ct",  0x1000, 0x1000, CRC(6d692d1b) SHA1(d6eff5b4718301ee425384a5ad9f286b3683c892) )
	ROM_LOAD( "dkongotr8.5et",  0x0000, 0x1000, CRC(243cb649) SHA1(5585c1d35863a290606345dfcd0e6190372c9a56) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "dkongotr7.3pt",  0x0800, 0x0800, CRC(bfb2c04f) SHA1(85b32c16537f53348489c6b9224822090a6b9789) )
	ROM_LOAD( "dkongotr7.5h",   0x0000, 0x0800, CRC(0d588de5) SHA1(17f133823dba09969d035907f4de154a0b859dc7) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "dkongotr6.4m",   0x0000, 0x0800, CRC(f224b2bc) SHA1(718368f6cfa41b73365e9da0705774fe41ca20bb) )
	ROM_LOAD( "dkongotr6.4n",   0x0800, 0x0800, CRC(def8bca4) SHA1(bd39b9a9fa0577fe38abf2576de2be43e792e513) )
	ROM_LOAD( "dkongotr6.4r",   0x1000, 0x0800, CRC(59e3e846) SHA1(444af5f47f7abd971a17313947500c083dc8caa1) )
	ROM_LOAD( "dkongotr6.4s",   0x1800, 0x0800, CRC(b5a2e920) SHA1(1ff2143539410b83139fccab0c799d39f61bf76c) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "c-2j.bpr",       0x0100, 0x0100, CRC(d6412358) SHA1(f9c872da2fe8e800574ae3bf483fb3ccacc92eb3) )
	ROM_LOAD( "c-2k.bpr",       0x0000, 0x0100, CRC(e273ede5) SHA1(b50ec9e1837c00c20fb2a4369ec7dd0358321127) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dkongotr9 )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkongotr9.5at",  0x3000, 0x1000, CRC(e380a2fb) SHA1(7b40d9ff32c22cb4209469d039ce89e399bf3a7e) )
	ROM_LOAD( "dkongotr8.5bt",  0x2000, 0x1000, CRC(d029c495) SHA1(3fc4a883ff7028a399a3452dcacee74fa50cc3db) )
	ROM_LOAD( "dkongotr8.5ct",  0x1000, 0x1000, CRC(6d692d1b) SHA1(d6eff5b4718301ee425384a5ad9f286b3683c892) )
	ROM_LOAD( "dkongotr9.5et",  0x0000, 0x1000, CRC(9ef703dd) SHA1(ada898fcc900581c0a55e6ed58598960ce98f12f) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "dkongotr7.3pt",  0x0800, 0x0800, CRC(bfb2c04f) SHA1(85b32c16537f53348489c6b9224822090a6b9789) )
	ROM_LOAD( "dkongotr7.5h",   0x0000, 0x0800, CRC(0d588de5) SHA1(17f133823dba09969d035907f4de154a0b859dc7) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "dkongotr6.4m",   0x0000, 0x0800, CRC(f224b2bc) SHA1(718368f6cfa41b73365e9da0705774fe41ca20bb) )
	ROM_LOAD( "dkongotr6.4n",   0x0800, 0x0800, CRC(def8bca4) SHA1(bd39b9a9fa0577fe38abf2576de2be43e792e513) )
	ROM_LOAD( "dkongotr6.4r",   0x1000, 0x0800, CRC(59e3e846) SHA1(444af5f47f7abd971a17313947500c083dc8caa1) )
	ROM_LOAD( "dkongotr6.4s",   0x1800, 0x0800, CRC(b5a2e920) SHA1(1ff2143539410b83139fccab0c799d39f61bf76c) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "c-2j.bpr",       0x0100, 0x0100, CRC(d6412358) SHA1(f9c872da2fe8e800574ae3bf483fb3ccacc92eb3) )
	ROM_LOAD( "c-2k.bpr",       0x0000, 0x0100, CRC(e273ede5) SHA1(b50ec9e1837c00c20fb2a4369ec7dd0358321127) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dkongotr )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkongotr.5et",   0x0000, 0x1000, CRC(fd64526a) SHA1(73e0cd21eb6befd5f370267811e83b4326dd4046) )
	ROM_LOAD( "dkongotr8.5ct",  0x1000, 0x1000, CRC(6d692d1b) SHA1(d6eff5b4718301ee425384a5ad9f286b3683c892) )
	ROM_LOAD( "dkongotr8.5bt",  0x2000, 0x1000, CRC(d029c495) SHA1(3fc4a883ff7028a399a3452dcacee74fa50cc3db) )
	ROM_LOAD( "dkongotr.5at",   0x3000, 0x1000, CRC(9b58b813) SHA1(72fd12e0ed25dfb3d9084666ea61b472d117e76e) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "dkongotr7.5h",   0x0000, 0x0800, CRC(0d588de5) SHA1(17f133823dba09969d035907f4de154a0b859dc7) )
	ROM_LOAD( "dkongotr7.3pt",  0x0800, 0x0800, CRC(bfb2c04f) SHA1(85b32c16537f53348489c6b9224822090a6b9789) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "dkongotr6.4m",   0x0000, 0x0800, CRC(f224b2bc) SHA1(718368f6cfa41b73365e9da0705774fe41ca20bb) )
	ROM_LOAD( "dkongotr6.4n",   0x0800, 0x0800, CRC(def8bca4) SHA1(bd39b9a9fa0577fe38abf2576de2be43e792e513) )
	ROM_LOAD( "dkongotr6.4r",   0x1000, 0x0800, CRC(59e3e846) SHA1(444af5f47f7abd971a17313947500c083dc8caa1) )
	ROM_LOAD( "dkongotr6.4s",   0x1800, 0x0800, CRC(b5a2e920) SHA1(1ff2143539410b83139fccab0c799d39f61bf76c) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "c-2k.bpr",       0x0000, 0x0100, CRC(e273ede5) SHA1(b50ec9e1837c00c20fb2a4369ec7dd0358321127) )
	ROM_LOAD( "c-2j.bpr",       0x0100, 0x0100, CRC(d6412358) SHA1(f9c872da2fe8e800574ae3bf483fb3ccacc92eb3) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dkongitd )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkongitd.5et",   0x0000, 0x1000, CRC(abddd83e) SHA1(37b4926f5bde6aba40c638884b3aa0e0a866d16a) )
	ROM_LOAD( "dkongitd.5ct",   0x1000, 0x1000, CRC(ee146d99) SHA1(67f1e176d5b189b25f3a99c9072752cb0b7122b9) )
	ROM_LOAD( "dkongchm.5bt",   0x2000, 0x1000, CRC(fce41e06) SHA1(fdab4f37f914d56a28092592f9cbb3d2502c925e) )
	ROM_LOAD( "dkongitd.5at",   0x3000, 0x1000, CRC(6b8d5524) SHA1(88ea04ae7ae3ba89c55a00ec1a23b7515225f9e9) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "dkongitd.5h",    0x0000, 0x0800, CRC(3d4ea8f8) SHA1(1726ad8de28e71c823b20296915623c8123f6165) )
	ROM_LOAD( "dkongitd.3pt",   0x0800, 0x0800, CRC(0979cf74) SHA1(6bce6b924a64b1e9260c228f538fc16ab380a87c) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "dkongitd.4m",    0x0000, 0x0800, CRC(21a04aa5) SHA1(65333757f6c640a32fffa5fef5fb26ed33579857) )
	ROM_LOAD( "dkongitd.4n",    0x0800, 0x0800, CRC(27ddec12) SHA1(c863b9c79510f20506865f9baadb9b6db43ba7dd) )
	ROM_LOAD( "dkongitd.4r",    0x1000, 0x0800, CRC(ddfee3e1) SHA1(8b6c27a71a749e329545b409692d735353e4f193) )
	ROM_LOAD( "dkongitd.4s",    0x1800, 0x0800, CRC(42d26b1b) SHA1(4b4b0f891865f009763e8d447f57fde5c0dd37ff) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "dkongitd.2k",    0x0000, 0x0100, CRC(8d918467) SHA1(a2e51ac14a4a6a1089a638c4c19c335be6b5a2a8) )
	ROM_LOAD( "dkongitd.2j",    0x0100, 0x0100, CRC(9aadf04a) SHA1(d88b624af808bd007e9ed05ba3e3d7f67e716da1) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dktwist0 )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dktwist0.5at",   0x3000, 0x1000, CRC(efa40f57) SHA1(61899f16af335158c08bd847c692496e252c85b2) )
	ROM_LOAD( "dktwist0.5bt",   0x2000, 0x1000, CRC(efbe0c5e) SHA1(6961f773556fdc115b86e28c484feed5ce024f7d) )
	ROM_LOAD( "dktwist0.5ct",   0x1000, 0x1000, CRC(e8a247f7) SHA1(f96d50e6306c6cfc8fe05e77936f90ac1f5d2f85) )
	ROM_LOAD( "dktwist0.5et",   0x0000, 0x1000, CRC(83059998) SHA1(4ea321991afc8a6e280c0e4ab29393af4dcced12) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "v_3pt.bin",      0x0800, 0x0800, CRC(15e9c5e9) SHA1(976eb1e18c74018193a35aa86cff482ebfc5cc4e) )
	ROM_LOAD( "v_5h_b.bin",     0x0000, 0x0800, CRC(12c8c95d) SHA1(a57ff5a231c45252a63b354137c920a1379b70a3) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "dktwist0.4m",    0x0000, 0x0800, CRC(95cbe0dc) SHA1(094479bd7ba8b56e2cb218b96110cdb318e473ac) )
	ROM_LOAD( "dktwist0.4n",    0x0800, 0x0800, CRC(72095b51) SHA1(955d168fa02b3cbddc43ca8ecc540bface695195) )
	ROM_LOAD( "dktwist0.4r",    0x1000, 0x0800, CRC(36d605e7) SHA1(0521d1ccf200ebe6f7f9a1d7d3041086f26cc085) )
	ROM_LOAD( "dktwist0.4s",    0x1800, 0x0800, CRC(9d0796a5) SHA1(b26f08070e5d912d1dd93b7f5f06bf1580aaf0f1) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "c-2j.bpr",       0x0100, 0x0100, CRC(d6412358) SHA1(f9c872da2fe8e800574ae3bf483fb3ccacc92eb3) )
	ROM_LOAD( "c-2k.bpr",       0x0000, 0x0100, CRC(e273ede5) SHA1(b50ec9e1837c00c20fb2a4369ec7dd0358321127) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dktwist )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dktwist.5at",    0x3000, 0x1000, CRC(a5eaceee) SHA1(ad936386642118afb40b1175c8830a3ed43612f3) )
	ROM_LOAD( "dktwist.5bt",    0x2000, 0x1000, CRC(1cbdd0a6) SHA1(cb0bde4db4dcfce5ba386061f1449b3647b36c76) )
	ROM_LOAD( "dktwist0.5ct",   0x1000, 0x1000, CRC(e8a247f7) SHA1(f96d50e6306c6cfc8fe05e77936f90ac1f5d2f85) )
	ROM_LOAD( "dktwist.5et",    0x0000, 0x1000, CRC(3b618106) SHA1(efe1c39f959665e8211285b8355200abade3f412) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "v_3pt.bin",      0x0800, 0x0800, CRC(15e9c5e9) SHA1(976eb1e18c74018193a35aa86cff482ebfc5cc4e) )
	ROM_LOAD( "v_5h_b.bin",     0x0000, 0x0800, CRC(12c8c95d) SHA1(a57ff5a231c45252a63b354137c920a1379b70a3) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "dktwist0.4m",    0x0000, 0x0800, CRC(95cbe0dc) SHA1(094479bd7ba8b56e2cb218b96110cdb318e473ac) )
	ROM_LOAD( "dktwist0.4n",    0x0800, 0x0800, CRC(72095b51) SHA1(955d168fa02b3cbddc43ca8ecc540bface695195) )
	ROM_LOAD( "dktwist0.4r",    0x1000, 0x0800, CRC(36d605e7) SHA1(0521d1ccf200ebe6f7f9a1d7d3041086f26cc085) )
	ROM_LOAD( "dktwist0.4s",    0x1800, 0x0800, CRC(9d0796a5) SHA1(b26f08070e5d912d1dd93b7f5f06bf1580aaf0f1) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "c-2j.bpr",       0x0100, 0x0100, CRC(d6412358) SHA1(f9c872da2fe8e800574ae3bf483fb3ccacc92eb3) )
	ROM_LOAD( "c-2k.bpr",       0x0000, 0x0100, CRC(e273ede5) SHA1(b50ec9e1837c00c20fb2a4369ec7dd0358321127) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dkjungle0 )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkjungle0.5at",  0x3000, 0x1000, CRC(6e120e2b) SHA1(4d1dd8a653afbde974ad72c06f64cd1a783b0d26) )
	ROM_LOAD( "dkjungle0.5bt",  0x2000, 0x1000, CRC(6f7158a3) SHA1(450925dfb2238b891c8b0693eb3fa38d5353eaff) )
	ROM_LOAD( "dktwist0.5ct",   0x1000, 0x1000, CRC(e8a247f7) SHA1(f96d50e6306c6cfc8fe05e77936f90ac1f5d2f85) )
	ROM_LOAD( "dkjungle0.5et",  0x0000, 0x1000, CRC(8012acdd) SHA1(49d3895f68724cb221811854d6f251aa7f3173a9) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "dkjungle0.3pt",  0x0800, 0x0800, CRC(95408f9f) SHA1(2783148806531d427c40b45bf568b45fdd9d3d79) )
	ROM_LOAD( "dkjungle0.5h",   0x0000, 0x0800, CRC(fccb93d6) SHA1(152e83a2e3002835f260f55adb53079bb502ae6d) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "dkjungle0.4m",   0x0000, 0x0800, CRC(3ee61846) SHA1(9c52912911878be0eb196612b9f328b2e40f475a) )
	ROM_LOAD( "dkjungle0.4n",   0x0800, 0x0800, CRC(d928f7a8) SHA1(fa4d6896cbe6b3178e81488a0ededa921aad0238) )
	ROM_LOAD( "dkjungle0.4r",   0x1000, 0x0800, CRC(12468998) SHA1(3ff1168936ff8e034524e09f737f4f33ed7bdb91) )
	ROM_LOAD( "dkjungle0.4s",   0x1800, 0x0800, CRC(d4cba860) SHA1(4afd92bad6136f9c674e96eb16b6f07a91deb937) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "dkjungle0.2j",   0x0100, 0x0100, CRC(a81ca93c) SHA1(349cdb6348cbe1773f217ebacb1f0ece144fa8fd) )
	ROM_LOAD( "dkjungle0.2k",   0x0000, 0x0100, CRC(84be5373) SHA1(5d091cbe4002c7f9adbab24b7e4c31409de4be32) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dkjungle )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkjungle.5at",   0x3000, 0x1000, CRC(6d1ea836) SHA1(2f59ce4b522b9c5aa1966b904a6089dfb9f9a89e) )
	ROM_LOAD( "dkjungle.5bt",   0x2000, 0x1000, CRC(b1990430) SHA1(7a99f07b95f1fb2f7ef0f443f74737153ec446ba) )
	ROM_LOAD( "dkjungle.5ct",   0x1000, 0x1000, CRC(ed5c7b13) SHA1(5c3865d50750eb4fd0fc36cccd1fbe3d7e59b29b) )
	ROM_LOAD( "dkjungle.5et",   0x0000, 0x1000, CRC(4ebc7956) SHA1(04a58199de5e247fe4335f8f1c54e5083f78934c) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "dkjungle0.3pt",  0x0800, 0x0800, CRC(95408f9f) SHA1(2783148806531d427c40b45bf568b45fdd9d3d79) )
	ROM_LOAD( "dkjungle0.5h",   0x0000, 0x0800, CRC(fccb93d6) SHA1(152e83a2e3002835f260f55adb53079bb502ae6d) )
 
	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "dkjungle.4m",    0x0000, 0x0800, CRC(5e77597e) SHA1(8b241f32bb1fec2c2a00ad75cb650c5eadc37bd3) )
	ROM_LOAD( "dkjungle.4n",    0x0800, 0x0800, CRC(715c29ff) SHA1(b5e544ebdc23b8ae236705f3f128261bb0f61ff6) )
	ROM_LOAD( "dkjungle.4r",    0x1000, 0x0800, CRC(7b24438d) SHA1(f34d532a11d0bcdd6e28cf0f4d4700e38228ff25) )
	ROM_LOAD( "dkjungle.4s",    0x1800, 0x0800, CRC(57d3989a) SHA1(3e17f2c197790a1985836ee5652288ce3bd5735d) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "dkjungle0.2j",   0x0100, 0x0100, CRC(a81ca93c) SHA1(349cdb6348cbe1773f217ebacb1f0ece144fa8fd) )
	ROM_LOAD( "dkjungle0.2k",   0x0000, 0x0100, CRC(84be5373) SHA1(5d091cbe4002c7f9adbab24b7e4c31409de4be32) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dkongtj )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkongtj.5et",    0x0000, 0x1000, CRC(63e2a483) SHA1(1e07674b77c51e5a50b5d7bd3bc7a77933e31d94) )
	ROM_LOAD( "dkjungle.5ct",   0x1000, 0x1000, CRC(ed5c7b13) SHA1(5c3865d50750eb4fd0fc36cccd1fbe3d7e59b29b) )
	ROM_LOAD( "dkjungle.5bt",   0x2000, 0x1000, CRC(b1990430) SHA1(7a99f07b95f1fb2f7ef0f443f74737153ec446ba) )
	ROM_LOAD( "dkongtj.5at",    0x3000, 0x1000, CRC(b4e0240a) SHA1(432a73d5f49ccd1c13402c5aac0bb64584de77ce) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "dkjungle0.3pt",  0x0800, 0x0800, CRC(95408f9f) SHA1(2783148806531d427c40b45bf568b45fdd9d3d79) )
	ROM_LOAD( "dkjungle0.5h",   0x0000, 0x0800, CRC(fccb93d6) SHA1(152e83a2e3002835f260f55adb53079bb502ae6d) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "dkjungle.4m",    0x0000, 0x0800, CRC(5e77597e) SHA1(8b241f32bb1fec2c2a00ad75cb650c5eadc37bd3) )
	ROM_LOAD( "dkjungle.4n",    0x0800, 0x0800, CRC(715c29ff) SHA1(b5e544ebdc23b8ae236705f3f128261bb0f61ff6) )
	ROM_LOAD( "dkjungle.4r",    0x1000, 0x0800, CRC(7b24438d) SHA1(f34d532a11d0bcdd6e28cf0f4d4700e38228ff25) )
	ROM_LOAD( "dkjungle.4s",    0x1800, 0x0800, CRC(57d3989a) SHA1(3e17f2c197790a1985836ee5652288ce3bd5735d) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "dkjungle0.2k",   0x0000, 0x0100, CRC(84be5373) SHA1(5d091cbe4002c7f9adbab24b7e4c31409de4be32) )
	ROM_LOAD( "dkjungle0.2j",   0x0100, 0x0100, CRC(a81ca93c) SHA1(349cdb6348cbe1773f217ebacb1f0ece144fa8fd) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dkbarpal2 )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkbarpal2.5at",  0x3000, 0x1000, CRC(c216f65b) SHA1(96910744a61b5dd85814af56673cc7ffa3443b15) )
	ROM_LOAD( "dkbarpal2.5bt",  0x2000, 0x1000, CRC(ae1057f2) SHA1(2665c1a5ba2a85832ebbf06ab0893192eb858473) )
	ROM_LOAD( "dkbarpal2.5ct",  0x1000, 0x1000, CRC(bb94a16b) SHA1(433d6f3a42c766cbf478c297c7d6025c738ffda6) )
	ROM_LOAD( "dkbarpal2.5et",  0x0000, 0x1000, CRC(4621e696) SHA1(bb61a347a157a668950fbf2f61950717ac1cc77a) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "dkbarpal2.3pt",  0x0800, 0x0800, CRC(b0cd1e84) SHA1(16f8404114e3f62e0789819f6a65f34189b595bc) )
	ROM_LOAD( "dkbarpal2.5h",   0x0000, 0x0800, CRC(caf8820b) SHA1(b3e5768bd19c16510d05cd9d5d7ad72e05d08a8c) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "dkbarpal2.4m",   0x0000, 0x0800, CRC(1b46aae1) SHA1(f08c57f2c85df81180444cab76acb4f367d71619) )
	ROM_LOAD( "dkbarpal2.4n",   0x0800, 0x0800, CRC(fbaaa6f0) SHA1(e61e92418270fb81d9fd33da0a92970d458f69e4) )
	ROM_LOAD( "dkbarpal2.4r",   0x1000, 0x0800, CRC(919362a0) SHA1(5df953cded45ad55ba2bbd5f6d5c7e4577dcaa5f) )
	ROM_LOAD( "dkbarpal2.4s",   0x1800, 0x0800, CRC(d57098ca) SHA1(b746b0e137844e0e1cb715df065bbf7a3246f2e9) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "dkbarpal2.2j",   0x0100, 0x0100, CRC(4a7a511b) SHA1(c0d3ee62e5f6e22d24603ab24403b206d043956f) )
	ROM_LOAD( "dkbarpal2.2k",   0x0000, 0x0100, CRC(4826ce71) SHA1(5fe7d63ce7adece81ab8930196434410fbe4e241) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dkbarpal3 )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkbarpal3.5at",  0x3000, 0x1000, CRC(d6d14fc3) SHA1(9e901825ed1c8dae40f5a9b6db804675b6c5ec70) )
	ROM_LOAD( "dkbarpal3.5bt",  0x2000, 0x1000, CRC(b526e924) SHA1(280c54d212f0d1c86a351277540570420ad73bff) )
	ROM_LOAD( "dkbarpal2.5ct",  0x1000, 0x1000, CRC(bb94a16b) SHA1(433d6f3a42c766cbf478c297c7d6025c738ffda6) )
	ROM_LOAD( "dkbarpal3.5et",  0x0000, 0x1000, CRC(3a79f8ad) SHA1(ef26bf95a8a9c37bced4e8172522dc34b5ca0ab4) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "dkbarpal2.3pt",  0x0800, 0x0800, CRC(b0cd1e84) SHA1(16f8404114e3f62e0789819f6a65f34189b595bc) )
	ROM_LOAD( "dkbarpal2.5h",   0x0000, 0x0800, CRC(caf8820b) SHA1(b3e5768bd19c16510d05cd9d5d7ad72e05d08a8c) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "dkbarpal2.4m",   0x0000, 0x0800, CRC(1b46aae1) SHA1(f08c57f2c85df81180444cab76acb4f367d71619) )
	ROM_LOAD( "dkbarpal2.4n",   0x0800, 0x0800, CRC(fbaaa6f0) SHA1(e61e92418270fb81d9fd33da0a92970d458f69e4) )
	ROM_LOAD( "dkbarpal2.4r",   0x1000, 0x0800, CRC(919362a0) SHA1(5df953cded45ad55ba2bbd5f6d5c7e4577dcaa5f) )
	ROM_LOAD( "dkbarpal2.4s",   0x1800, 0x0800, CRC(d57098ca) SHA1(b746b0e137844e0e1cb715df065bbf7a3246f2e9) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "dkbarpal2.2j",   0x0100, 0x0100, CRC(4a7a511b) SHA1(c0d3ee62e5f6e22d24603ab24403b206d043956f) )
	ROM_LOAD( "dkbarpal2.2k",   0x0000, 0x0100, CRC(4826ce71) SHA1(5fe7d63ce7adece81ab8930196434410fbe4e241) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dkbarpal4 )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkbarpal4.5at",  0x3000, 0x1000, CRC(f162e9ef) SHA1(674a005139255c454a09df7701eda2e29868f97a) )
	ROM_LOAD( "dkbarpal4.5bt",  0x2000, 0x1000, CRC(dbf5b518) SHA1(fe4f1fe9baeb588941fe991541f3a5197a0ca860) )
	ROM_LOAD( "dkbarpal2.5ct",  0x1000, 0x1000, CRC(bb94a16b) SHA1(433d6f3a42c766cbf478c297c7d6025c738ffda6) )
	ROM_LOAD( "dkbarpal4.5et",  0x0000, 0x1000, CRC(bb5c7dca) SHA1(f4bab16cb33ecca302fa6dd39b718a292958c691) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "dkbarpal.3i",    0x0000, 0x0800, CRC(7590f5ee) SHA1(b08245ce86d2c2de1b0d000743b7e9fcdf2ee215) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "dkbarpal2.3pt",  0x0800, 0x0800, CRC(b0cd1e84) SHA1(16f8404114e3f62e0789819f6a65f34189b595bc) )
	ROM_LOAD( "dkbarpal2.5h",   0x0000, 0x0800, CRC(caf8820b) SHA1(b3e5768bd19c16510d05cd9d5d7ad72e05d08a8c) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "dkbarpal2.4m",   0x0000, 0x0800, CRC(1b46aae1) SHA1(f08c57f2c85df81180444cab76acb4f367d71619) )
	ROM_LOAD( "dkbarpal2.4n",   0x0800, 0x0800, CRC(fbaaa6f0) SHA1(e61e92418270fb81d9fd33da0a92970d458f69e4) )
	ROM_LOAD( "dkbarpal2.4r",   0x1000, 0x0800, CRC(919362a0) SHA1(5df953cded45ad55ba2bbd5f6d5c7e4577dcaa5f) )
	ROM_LOAD( "dkbarpal2.4s",   0x1800, 0x0800, CRC(d57098ca) SHA1(b746b0e137844e0e1cb715df065bbf7a3246f2e9) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "dkbarpal2.2j",   0x0100, 0x0100, CRC(4a7a511b) SHA1(c0d3ee62e5f6e22d24603ab24403b206d043956f) )
	ROM_LOAD( "dkbarpal2.2k",   0x0000, 0x0100, CRC(4826ce71) SHA1(5fe7d63ce7adece81ab8930196434410fbe4e241) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dkbarpal5 )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkbarpal5.5at",  0x3000, 0x1000, CRC(0791b6e1) SHA1(6feeb6cd3b2b498e9ab3d2f9e548b54b2578af81) )
	ROM_LOAD( "dkbarpal4.5bt",  0x2000, 0x1000, CRC(dbf5b518) SHA1(fe4f1fe9baeb588941fe991541f3a5197a0ca860) )
	ROM_LOAD( "dkbarpal5.5ct",  0x1000, 0x1000, CRC(b543574d) SHA1(dd8b260c8671cf560fa1348075f535aedfd8b418) )
	ROM_LOAD( "dkbarpal4.5et",  0x0000, 0x1000, CRC(bb5c7dca) SHA1(f4bab16cb33ecca302fa6dd39b718a292958c691) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "dkbarpal.3i",    0x0000, 0x0800, CRC(7590f5ee) SHA1(b08245ce86d2c2de1b0d000743b7e9fcdf2ee215) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "dkbarpal2.3pt",  0x0800, 0x0800, CRC(b0cd1e84) SHA1(16f8404114e3f62e0789819f6a65f34189b595bc) )
	ROM_LOAD( "dkbarpal2.5h",   0x0000, 0x0800, CRC(caf8820b) SHA1(b3e5768bd19c16510d05cd9d5d7ad72e05d08a8c) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "dkbarpal2.4m",   0x0000, 0x0800, CRC(1b46aae1) SHA1(f08c57f2c85df81180444cab76acb4f367d71619) )
	ROM_LOAD( "dkbarpal2.4n",   0x0800, 0x0800, CRC(fbaaa6f0) SHA1(e61e92418270fb81d9fd33da0a92970d458f69e4) )
	ROM_LOAD( "dkbarpal2.4r",   0x1000, 0x0800, CRC(919362a0) SHA1(5df953cded45ad55ba2bbd5f6d5c7e4577dcaa5f) )
	ROM_LOAD( "dkbarpal2.4s",   0x1800, 0x0800, CRC(d57098ca) SHA1(b746b0e137844e0e1cb715df065bbf7a3246f2e9) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "dkbarpal2.2j",   0x0100, 0x0100, CRC(4a7a511b) SHA1(c0d3ee62e5f6e22d24603ab24403b206d043956f) )
	ROM_LOAD( "dkbarpal2.2k",   0x0000, 0x0100, CRC(4826ce71) SHA1(5fe7d63ce7adece81ab8930196434410fbe4e241) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dkbarpal6 )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkbarpal4.5et",  0x0000, 0x1000, CRC(bb5c7dca) SHA1(f4bab16cb33ecca302fa6dd39b718a292958c691) )
	ROM_LOAD( "dkbarpal6.5ct",  0x1000, 0x1000, CRC(c742739c) SHA1(a143af813f7c23b6bab483ad2610e686ebc568da) )
	ROM_LOAD( "dkbarpal6.5bt",  0x2000, 0x1000, CRC(a46859ec) SHA1(bbe8a32b7396f6347ce8b4a77b760277fb965551) )
	ROM_LOAD( "dkbarpal6.5at",  0x3000, 0x1000, CRC(eafd7c54) SHA1(1b44ac9c90621a8aeda00ef2677e9ad00d475467) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "dkbarpal.3i",    0x0000, 0x0800, CRC(7590f5ee) SHA1(b08245ce86d2c2de1b0d000743b7e9fcdf2ee215) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "dkbarpal2.5h",   0x0000, 0x0800, CRC(caf8820b) SHA1(b3e5768bd19c16510d05cd9d5d7ad72e05d08a8c) )
	ROM_LOAD( "dkbarpal2.3pt",  0x0800, 0x0800, CRC(b0cd1e84) SHA1(16f8404114e3f62e0789819f6a65f34189b595bc) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "dkbarpal2.4m",   0x0000, 0x0800, CRC(1b46aae1) SHA1(f08c57f2c85df81180444cab76acb4f367d71619) )
	ROM_LOAD( "dkbarpal2.4n",   0x0800, 0x0800, CRC(fbaaa6f0) SHA1(e61e92418270fb81d9fd33da0a92970d458f69e4) )
	ROM_LOAD( "dkbarpal2.4r",   0x1000, 0x0800, CRC(919362a0) SHA1(5df953cded45ad55ba2bbd5f6d5c7e4577dcaa5f) )
	ROM_LOAD( "dkbarpal2.4s",   0x1800, 0x0800, CRC(d57098ca) SHA1(b746b0e137844e0e1cb715df065bbf7a3246f2e9) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "dkbarpal2.2k",   0x0000, 0x0100, CRC(4826ce71) SHA1(5fe7d63ce7adece81ab8930196434410fbe4e241) )
	ROM_LOAD( "dkbarpal2.2j",   0x0100, 0x0100, CRC(4a7a511b) SHA1(c0d3ee62e5f6e22d24603ab24403b206d043956f) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dkbarpal )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkbarpal.5et",   0x0000, 0x1000, CRC(c80c0431) SHA1(446e897150d027f797edbe30d0502f5f5a652ba7) )
	ROM_LOAD( "dkbarpal6.5ct",  0x1000, 0x1000, CRC(c742739c) SHA1(a143af813f7c23b6bab483ad2610e686ebc568da) )
	ROM_LOAD( "dkbarpal6.5bt",  0x2000, 0x1000, CRC(a46859ec) SHA1(bbe8a32b7396f6347ce8b4a77b760277fb965551) )
	ROM_LOAD( "dkbarpal.5at",   0x3000, 0x1000, CRC(4742a48e) SHA1(ddef0c7e25cbeba37a387de1d72583a2861dbbf4) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "dkbarpal.3i",    0x0000, 0x0800, CRC(7590f5ee) SHA1(b08245ce86d2c2de1b0d000743b7e9fcdf2ee215) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "dkbarpal2.5h",   0x0000, 0x0800, CRC(caf8820b) SHA1(b3e5768bd19c16510d05cd9d5d7ad72e05d08a8c) )
	ROM_LOAD( "dkbarpal2.3pt",  0x0800, 0x0800, CRC(b0cd1e84) SHA1(16f8404114e3f62e0789819f6a65f34189b595bc) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "dkbarpal2.4m",   0x0000, 0x0800, CRC(1b46aae1) SHA1(f08c57f2c85df81180444cab76acb4f367d71619) )
	ROM_LOAD( "dkbarpal2.4n",   0x0800, 0x0800, CRC(fbaaa6f0) SHA1(e61e92418270fb81d9fd33da0a92970d458f69e4) )
	ROM_LOAD( "dkbarpal2.4r",   0x1000, 0x0800, CRC(919362a0) SHA1(5df953cded45ad55ba2bbd5f6d5c7e4577dcaa5f) )
	ROM_LOAD( "dkbarpal2.4s",   0x1800, 0x0800, CRC(d57098ca) SHA1(b746b0e137844e0e1cb715df065bbf7a3246f2e9) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "dkbarpal2.2k",   0x0000, 0x0100, CRC(4826ce71) SHA1(5fe7d63ce7adece81ab8930196434410fbe4e241) )
	ROM_LOAD( "dkbarpal2.2j",   0x0100, 0x0100, CRC(4a7a511b) SHA1(c0d3ee62e5f6e22d24603ab24403b206d043956f) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dkongan0 )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkongan0.5at",   0x3000, 0x1000, CRC(56ef8519) SHA1(6dab077e190da06d79496cb6b92cbd34ea36e935) )
	ROM_LOAD( "dkongan0.5bt",   0x2000, 0x1000, CRC(6c5614e5) SHA1(cf8a31c303eb18260cc328593f365ebd9d81fb5c) )
	ROM_LOAD( "dkongan0.5ct",   0x1000, 0x1000, CRC(34238a95) SHA1(a997989a33d5ad8dc77483781de12fd161e57f39) )
	ROM_LOAD( "dkongan0.5et",   0x0000, 0x1000, CRC(c3f2ed18) SHA1(e598f85c6c375a9202e8628b390165186d287f55) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "dkongan.3i",     0x0000, 0x0800, CRC(44993c29) SHA1(7beeae49df5126bbf268dc66bb61e6a8b832fa31) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "dkongan0.3pt",   0x0800, 0x0800, CRC(25cc07d4) SHA1(62374e89c79527cb78a70f83781299d4786bcec0) )
	ROM_LOAD( "dkongan0.5h",    0x0000, 0x0800, CRC(ae4c3990) SHA1(20db41211bfdc6b79198fc8cd022465468430059) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "dkongan0.4m",     0x0000, 0x0800, CRC(410ab9a2) SHA1(c98f2053bc2f2140209ac2d8d0a7c1f489ec429c) )
	ROM_LOAD( "dkongan0.4n",     0x0800, 0x0800, CRC(4f7e8fd4) SHA1(b031f512a40d6cdd430cc57f470efe53e55fbad7) )
	ROM_LOAD( "dkongan0.4r",     0x1000, 0x0800, CRC(9eb470c0) SHA1(58644eed4c4f0b714f51147fbf77b9c2ee18ad2c) )
	ROM_LOAD( "dkongan0.4s",     0x1800, 0x0800, CRC(73ef61cc) SHA1(7736e1451a36f1b9b20108c0d5f6ba861602d307) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "c-2j.bpr",       0x0100, 0x0100, CRC(d6412358) SHA1(f9c872da2fe8e800574ae3bf483fb3ccacc92eb3) )
	ROM_LOAD( "c-2k.bpr",       0x0000, 0x0100, CRC(e273ede5) SHA1(b50ec9e1837c00c20fb2a4369ec7dd0358321127) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dkongan )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkongan.5et",    0x0000, 0x1000, CRC(cf44c2dd) SHA1(26776fa00250fbffdc1cb2ef012f851cffd67b3d) )
	ROM_LOAD( "dkongan0.5ct",   0x1000, 0x1000, CRC(34238a95) SHA1(a997989a33d5ad8dc77483781de12fd161e57f39) )
	ROM_LOAD( "dkongan0.5bt",   0x2000, 0x1000, CRC(6c5614e5) SHA1(cf8a31c303eb18260cc328593f365ebd9d81fb5c) )
	ROM_LOAD( "dkongan.5at",    0x3000, 0x1000, CRC(0b92803c) SHA1(01bb401837ddeeb5ff36d98eebde9a5819ac19e8) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "dkongan.3i",     0x0000, 0x0800, CRC(44993c29) SHA1(7beeae49df5126bbf268dc66bb61e6a8b832fa31) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "dkongan0.5h",    0x0000, 0x0800, CRC(ae4c3990) SHA1(20db41211bfdc6b79198fc8cd022465468430059) )
	ROM_LOAD( "dkongan0.3pt",   0x0800, 0x0800, CRC(25cc07d4) SHA1(62374e89c79527cb78a70f83781299d4786bcec0) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "dkongan0.4m",    0x0000, 0x0800, CRC(410ab9a2) SHA1(c98f2053bc2f2140209ac2d8d0a7c1f489ec429c) )
	ROM_LOAD( "dkongan0.4n",    0x0800, 0x0800, CRC(4f7e8fd4) SHA1(b031f512a40d6cdd430cc57f470efe53e55fbad7) )
	ROM_LOAD( "dkongan0.4r",    0x1000, 0x0800, CRC(9eb470c0) SHA1(58644eed4c4f0b714f51147fbf77b9c2ee18ad2c) )
	ROM_LOAD( "dkongan0.4s",    0x1800, 0x0800, CRC(73ef61cc) SHA1(7736e1451a36f1b9b20108c0d5f6ba861602d307) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "c-2k.bpr",       0x0000, 0x0100, CRC(e273ede5) SHA1(b50ec9e1837c00c20fb2a4369ec7dd0358321127) )
	ROM_LOAD( "c-2j.bpr",       0x0100, 0x0100, CRC(d6412358) SHA1(f9c872da2fe8e800574ae3bf483fb3ccacc92eb3) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END

ROM_START( dkongdu0 )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkongdu0.5at",   0x3000, 0x1000, CRC(5e7fff6a) SHA1(6538160a1ed8c583dc5e0525ed85da7e144dc887) )
	ROM_LOAD( "dkongchm.5bt",   0x2000, 0x1000, CRC(fce41e06) SHA1(fdab4f37f914d56a28092592f9cbb3d2502c925e) )
	ROM_LOAD( "dkongdu0.5ct",   0x1000, 0x1000, CRC(fc9cdaa0) SHA1(964ac1d908c5abfaa4aa459f52f4ead133d41346) )
	ROM_LOAD( "dkongdu0.5et",   0x0000, 0x1000, CRC(87a4912f) SHA1(bca9f1c489c193f4cd15a108dd4dd2d99aa89c35) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "dkongdu0.3i",    0x0000, 0x0800, CRC(cc9aea3b) SHA1(e5b985efc1447ad04cfe347a7b761c9e5ff8ea5c) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "dkongdu0.5h",    0x0000, 0x0800, CRC(3cf6ef8b) SHA1(d4f1ac5dfa93b7073d9b441f05b24077c0d22924) )
	ROM_LOAD( "dkongdu0.3pt",   0x0800, 0x0800, CRC(3775dd7b) SHA1(0e73e1e64673140e8e5fd318cc679c64812608a7) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "l_4m_b.bin",     0x0000, 0x0800, CRC(59f8054d) SHA1(793dba9bf5a5fe76328acdfb90815c243d2a65f1) )
	ROM_LOAD( "l_4n_b.bin",     0x0800, 0x0800, CRC(672e4714) SHA1(92e5d379f4838ac1fa44d448ce7d142dae42102f) )
	ROM_LOAD( "l_4r_b.bin",     0x1000, 0x0800, CRC(feaa59ee) SHA1(ecf95db5a20098804fc8bd59232c66e2e0ed3db4) )
	ROM_LOAD( "l_4s_b.bin",     0x1800, 0x0800, CRC(20f2ef7e) SHA1(3bc482a38bf579033f50082748ee95205b0f673d) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "dkongdu0.2k",    0x0000, 0x0100, CRC(02e1f91b) SHA1(fadb853a060db98ea13d67059fda91e7095b0050) )
	ROM_LOAD( "dkongdu0.2j",    0x0100, 0x0100, CRC(4176057f) SHA1(ccb7d553f6aa82bff4d30da9b97d107684f329ca) )
	ROM_LOAD( "dkongdu0.5e",    0x0200, 0x0100, CRC(94695888) SHA1(fc0167730b303c9743d24dba577b6a72ffc07c15) )
ROM_END

ROM_START( dkongdu1 )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkongdu0.5et",   0x0000, 0x1000, CRC(87a4912f) SHA1(bca9f1c489c193f4cd15a108dd4dd2d99aa89c35) )
	ROM_LOAD( "dkongdu1.5ct",   0x1000, 0x1000, CRC(1f574afa) SHA1(5fe8291bc14539cf25db245e05d90f35e96674dc) )
	ROM_LOAD( "dkongchm.5bt",   0x2000, 0x1000, CRC(fce41e06) SHA1(fdab4f37f914d56a28092592f9cbb3d2502c925e) )
	ROM_LOAD( "dkongdu1.5at",   0x3000, 0x1000, CRC(11b03279) SHA1(412e5036db0b39e318f97736665e15cbd5690cb0) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "dkongdu0.3i",    0x0000, 0x0800, CRC(cc9aea3b) SHA1(e5b985efc1447ad04cfe347a7b761c9e5ff8ea5c) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "dkongdu0.5h",    0x0000, 0x0800, CRC(3cf6ef8b) SHA1(d4f1ac5dfa93b7073d9b441f05b24077c0d22924) )
	ROM_LOAD( "dkongdu0.3pt",   0x0800, 0x0800, CRC(3775dd7b) SHA1(0e73e1e64673140e8e5fd318cc679c64812608a7) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "l_4m_b.bin",     0x0000, 0x0800, CRC(59f8054d) SHA1(793dba9bf5a5fe76328acdfb90815c243d2a65f1) )
	ROM_LOAD( "l_4n_b.bin",     0x0800, 0x0800, CRC(672e4714) SHA1(92e5d379f4838ac1fa44d448ce7d142dae42102f) )
	ROM_LOAD( "l_4r_b.bin",     0x1000, 0x0800, CRC(feaa59ee) SHA1(ecf95db5a20098804fc8bd59232c66e2e0ed3db4) )
	ROM_LOAD( "l_4s_b.bin",     0x1800, 0x0800, CRC(20f2ef7e) SHA1(3bc482a38bf579033f50082748ee95205b0f673d) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "dkongdu0.2k",    0x0000, 0x0100, CRC(02e1f91b) SHA1(fadb853a060db98ea13d67059fda91e7095b0050) )
	ROM_LOAD( "dkongdu0.2j",    0x0100, 0x0100, CRC(4176057f) SHA1(ccb7d553f6aa82bff4d30da9b97d107684f329ca) )
	ROM_LOAD( "dkongdu0.5e",    0x0200, 0x0100, CRC(94695888) SHA1(fc0167730b303c9743d24dba577b6a72ffc07c15) )
ROM_END

ROM_START( dkongdu )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkongdu0.5et",   0x0000, 0x1000, CRC(87a4912f) SHA1(bca9f1c489c193f4cd15a108dd4dd2d99aa89c35) )
	ROM_LOAD( "dkongdu.5ct",    0x1000, 0x1000, CRC(1c547c2b) SHA1(d5373bae4e3a067821253ec6e0e5169a2bfd9dfe) )
	ROM_LOAD( "dkongchm.5bt",   0x2000, 0x1000, CRC(fce41e06) SHA1(fdab4f37f914d56a28092592f9cbb3d2502c925e) )
	ROM_LOAD( "dkongdu.5at",    0x3000, 0x1000, CRC(c1e0654c) SHA1(decf2a73730b117d977ca90039a9b93651883f8d) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "dkongdu0.3i",    0x0000, 0x0800, CRC(cc9aea3b) SHA1(e5b985efc1447ad04cfe347a7b761c9e5ff8ea5c) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "dkongdu0.5h",    0x0000, 0x0800, CRC(3cf6ef8b) SHA1(d4f1ac5dfa93b7073d9b441f05b24077c0d22924) )
	ROM_LOAD( "dkongdu0.3pt",   0x0800, 0x0800, CRC(3775dd7b) SHA1(0e73e1e64673140e8e5fd318cc679c64812608a7) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "l_4m_b.bin",     0x0000, 0x0800, CRC(59f8054d) SHA1(793dba9bf5a5fe76328acdfb90815c243d2a65f1) )
	ROM_LOAD( "l_4n_b.bin",     0x0800, 0x0800, CRC(672e4714) SHA1(92e5d379f4838ac1fa44d448ce7d142dae42102f) )
	ROM_LOAD( "l_4r_b.bin",     0x1000, 0x0800, CRC(feaa59ee) SHA1(ecf95db5a20098804fc8bd59232c66e2e0ed3db4) )
	ROM_LOAD( "l_4s_b.bin",     0x1800, 0x0800, CRC(20f2ef7e) SHA1(3bc482a38bf579033f50082748ee95205b0f673d) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "dkongdu0.2k",    0x0000, 0x0100, CRC(02e1f91b) SHA1(fadb853a060db98ea13d67059fda91e7095b0050) )
	ROM_LOAD( "dkongdu0.2j",    0x0100, 0x0100, CRC(4176057f) SHA1(ccb7d553f6aa82bff4d30da9b97d107684f329ca) )
	ROM_LOAD( "dkongdu0.5e",    0x0200, 0x0100, CRC(94695888) SHA1(fc0167730b303c9743d24dba577b6a72ffc07c15) )
ROM_END

ROM_START( dkwizard0 )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkwizard0.5at",  0x3000, 0x1000, CRC(934e1f36) SHA1(7f1116f0f7b459578931e69cd88bdc78986bcf73) )
	ROM_LOAD( "dkwizard0.5bt",  0x2000, 0x1000, CRC(8d5bda23) SHA1(ca2d1f9a7d8abc56c583cb510075fd2e4cee2d85) )
	ROM_LOAD( "dkwizard0.5ct",  0x1000, 0x1000, CRC(9d276435) SHA1(8ef89c3bb10a01c4a438918a4f777eb4ea5b08bb) )
	ROM_LOAD( "dkwizard0.5et",  0x0000, 0x1000, CRC(95dd923b) SHA1(3704da244d7ade149a9a22060a95d64ce2e47571) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "dkwizard0.3pt",  0x0800, 0x0800, CRC(8f6e6c62) SHA1(53cac9a77cbd068d775541a876e7f5f450d03a81) )
	ROM_LOAD( "dkwizard0.5h",   0x0000, 0x0800, CRC(8d54ad8d) SHA1(58ef5d7a9d7a45473b7724e216a0a4027562049b) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "dkwizard0.4m",   0x0000, 0x0800, CRC(700944c8) SHA1(7915bae6c9d062ef5b13d7bc43297785692e9115) )
	ROM_LOAD( "dkwizard0.4n",   0x0800, 0x0800, CRC(cf3cdb75) SHA1(9ac98e0cfada360b9615af1c14c2d5e27129f328) )
	ROM_LOAD( "dkwizard0.4r",   0x1000, 0x0800, CRC(e6e9b11e) SHA1(86cda6de37c1da0476223138a56449f36f1e2b14) )
	ROM_LOAD( "dkwizard0.4s",   0x1800, 0x0800, CRC(dd1432a0) SHA1(18ef383485a77866b29c05b66992c3cc6cc4f5ea) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "dkwizard0.2k",   0x0000, 0x0100, CRC(6a3503a9) SHA1(10f416c915219ea7303f4e4b31cb6f499a04154d) )
	ROM_LOAD( "dkwizard0.2j",   0x0100, 0x0100, CRC(c5e5326c) SHA1(5d809737ed4ab9242d310f4cbe46636d3570d873) )
	ROM_LOAD( "dkwizard0.5e",   0x0200, 0x0100, CRC(c24f2312) SHA1(61dfcec8ecaa7a38ed222f2d3c4d6695db6f33b1) )
ROM_END

ROM_START( dkwizard1 )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkwizard1.5at",  0x3000, 0x1000, CRC(277e3f4b) SHA1(66db4fe02ef7d6860b45f4222793f0d8e1a3e1f8) )
	ROM_LOAD( "dkwizard0.5bt",  0x2000, 0x1000, CRC(8d5bda23) SHA1(ca2d1f9a7d8abc56c583cb510075fd2e4cee2d85) )
	ROM_LOAD( "dkwizard1.5ct",  0x1000, 0x1000, CRC(1ba39916) SHA1(9c0b7d178134fbf2b6a55dc4e1e40011d9464c45) )
	ROM_LOAD( "dkwizard0.5et",  0x0000, 0x1000, CRC(95dd923b) SHA1(3704da244d7ade149a9a22060a95d64ce2e47571) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "dkwizard1.5h",   0x0000, 0x0800, CRC(39736a8a) SHA1(8825f1473415fc588a189887f4aa302313bfcec8) )
	ROM_LOAD( "dkwizard1.3pt",  0x0800, 0x0800, CRC(c94468a9) SHA1(136b204735223c5e3f94340db5f6b7cfd0ad2666) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "dkwizard1.4m",   0x0000, 0x0800, CRC(f98da4c5) SHA1(362c2083b0bad94174c3bd2e77b52dee18069d00) )
	ROM_LOAD( "dkwizard0.4n",   0x0800, 0x0800, CRC(cf3cdb75) SHA1(9ac98e0cfada360b9615af1c14c2d5e27129f328) )
	ROM_LOAD( "dkwizard1.4r",   0x1000, 0x0800, CRC(7e2d1ef4) SHA1(2f6d2d7afd4b595b2e24e31263433611e9761c86) )
	ROM_LOAD( "dkwizard1.4s",   0x1800, 0x0800, CRC(cc547d47) SHA1(087f9c5da33831d2a7a9f5f86d9da1d7f1cf15b6) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "dkwizard1.2k",   0x0000, 0x0100, CRC(193134e9) SHA1(6101bbdff23f0a1ccaba99cdbd966bcf780751bd) )
	ROM_LOAD( "dkwizard1.2j",   0x0100, 0x0100, CRC(dcbba451) SHA1(31bf6bc17f790d4a61392ca1fd68361698ac9338) )
	ROM_LOAD( "dkwizard0.5e",   0x0200, 0x0100, CRC(c24f2312) SHA1(61dfcec8ecaa7a38ed222f2d3c4d6695db6f33b1) )
ROM_END

ROM_START( dkwizard )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dkwizard.5et",   0x0000, 0x1000, CRC(f42bb2e5) SHA1(2bd74d51d9ce43207f2ec879746ec44bdd13aef1) )
	ROM_LOAD( "dkwizard.5ct",   0x1000, 0x1000, CRC(85cf6e4c) SHA1(4140865b1dabee98346f4217e9b7b355d177ebc7) )
	ROM_LOAD( "dkwizard0.5bt",  0x2000, 0x1000, CRC(8d5bda23) SHA1(ca2d1f9a7d8abc56c583cb510075fd2e4cee2d85) )
	ROM_LOAD( "dkwizard.5at",   0x3000, 0x1000, CRC(f72e687e) SHA1(e2575f6e0f9d3ae1d40fbb22084439a84d103e30) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "dkwizard1.5h",   0x0000, 0x0800, CRC(39736a8a) SHA1(8825f1473415fc588a189887f4aa302313bfcec8) )
	ROM_LOAD( "dkwizard1.3pt",  0x0800, 0x0800, CRC(c94468a9) SHA1(136b204735223c5e3f94340db5f6b7cfd0ad2666) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "dkwizard1.4m",   0x0000, 0x0800, CRC(f98da4c5) SHA1(362c2083b0bad94174c3bd2e77b52dee18069d00) )
	ROM_LOAD( "dkwizard0.4n",   0x0800, 0x0800, CRC(cf3cdb75) SHA1(9ac98e0cfada360b9615af1c14c2d5e27129f328) )
	ROM_LOAD( "dkwizard1.4r",   0x1000, 0x0800, CRC(7e2d1ef4) SHA1(2f6d2d7afd4b595b2e24e31263433611e9761c86) )
	ROM_LOAD( "dkwizard1.4s",   0x1800, 0x0800, CRC(cc547d47) SHA1(087f9c5da33831d2a7a9f5f86d9da1d7f1cf15b6) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "dkwizard1.2k",   0x0000, 0x0100, CRC(193134e9) SHA1(6101bbdff23f0a1ccaba99cdbd966bcf780751bd) )
	ROM_LOAD( "dkwizard1.2j",   0x0100, 0x0100, CRC(dcbba451) SHA1(31bf6bc17f790d4a61392ca1fd68361698ac9338) )
	ROM_LOAD( "dkwizard0.5e",   0x0200, 0x0100, CRC(c24f2312) SHA1(61dfcec8ecaa7a38ed222f2d3c4d6695db6f33b1) )
ROM_END

ROM_START( dksprfin )
	ROM_REGION( 0x10000, "maincpu", 0 )
	ROM_LOAD( "dksprfin.5et",   0x0000, 0x1000, CRC(fd23db80) SHA1(2188bf0c8943e9c4771c3f9ff3bd1cfcc14a5ba4) )
	ROM_LOAD( "dksprfin.5ct",   0x1000, 0x1000, CRC(3ee5db14) SHA1(ff984eb269064f10305bbeeaa68a1d3160e0b1fa) )
	ROM_LOAD( "dksprfin.5bt",   0x2000, 0x1000, CRC(50772c6c) SHA1(4368d4501e3d971929015c545aef88d9c06e0604) )
	ROM_LOAD( "dksprfin.5at",   0x3000, 0x1000, CRC(5a31dc81) SHA1(44015be4a70dc75035edfe4b7ba19bbfed6c249a) )

	ROM_REGION( 0x1800, "soundcpu", 0 )
	ROM_LOAD( "s_3i_b.bin",     0x0000, 0x0800, CRC(45a4ed06) SHA1(144d24464c1f9f01894eb12f846952290e6e32ef) )
	ROM_RELOAD(                 0x0800, 0x0800 )
	ROM_LOAD( "s_3j_b.bin",     0x1000, 0x0800, CRC(4743fe92) SHA1(6c82b57637c0212a580591397e6a5a1718f19fd2) )

	ROM_REGION( 0x1000, "gfx1", 0 )
	ROM_LOAD( "dksprfin.5h",    0x0000, 0x0800, CRC(b41e2713) SHA1(2a4e37e5bb997b0a6a0d8aef61fd8f89d97d8213) )
	ROM_LOAD( "dksprfin.3pt",   0x0800, 0x0800, CRC(b33f2ba7) SHA1(900ff22f44b4504da4f3b8fe9dcdf7f5b88ea597) )

	ROM_REGION( 0x2000, "gfx2", 0 )
	ROM_LOAD( "dksprfin.4m",    0x0000, 0x0800, CRC(59f8054d) SHA1(793dba9bf5a5fe76328acdfb90815c243d2a65f1) )
	ROM_LOAD( "dksprfin.4n",    0x0800, 0x0800, CRC(672e4714) SHA1(92e5d379f4838ac1fa44d448ce7d142dae42102f) )
	ROM_LOAD( "dksprfin.4r",    0x1000, 0x0800, CRC(feaa59ee) SHA1(ecf95db5a20098804fc8bd59232c66e2e0ed3db4) )
	ROM_LOAD( "dksprfin.4s",    0x1800, 0x0800, CRC(20f2ef7e) SHA1(3bc482a38bf579033f50082748ee95205b0f673d) )

	ROM_REGION( 0x0300, "proms", 0 )
	ROM_LOAD( "dksprfin.2k",    0x0000, 0x0100, CRC(6baa5ba0) SHA1(2c0e9f4b4ac2d14aeeeba9afa9bf675337650276) )
	ROM_LOAD( "dksprfin.2j",    0x0100, 0x0100, CRC(1a144a25) SHA1(6e73470b7589ea5f14cf0dd9a9fbfd176e5e1c36) )
	ROM_LOAD( "v-5e.bpr",       0x0200, 0x0100, CRC(b869b8f5) SHA1(c2bdccbf2654b64ea55cd589fd21323a9178a660) )
ROM_END


GAME( 1981, dkongbcc,  dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Jeff Kulczycki", "Donkey Kong (US set 1 with barrel control coloring)", MACHINE_SUPPORTS_SAVE )
GAME( 1999, kong2600,  dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Vic Twenty George", "Donkey Kong (2600 graphics)", MACHINE_SUPPORTS_SAVE )
GAME( 2001, dkongpac,  dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Tim Appleton", "Donkey Kong (Pacman graphics)", MACHINE_SUPPORTS_SAVE )
GAME( 2004, nadkong,   dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "hack", "Naked Donkey Kong", MACHINE_SUPPORTS_SAVE )
GAME( 2005, dkongex,   dkong, dkong2b,   dkongex, dkong_state,  empty_init,  ROT270, "Jeff Kulczycki", "Donkey Kong Foundry", MACHINE_SUPPORTS_SAVE )
GAME( 2007, dkongp,    dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Don Hodges", "Donkey Kong (patched)", MACHINE_SUPPORTS_SAVE )
GAME( 2013, dkong2m,   dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "hack", "Donkey Kong (2 marios)", MACHINE_SUPPORTS_SAVE )
GAME( 2015, dkrainbow, dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Sock Master", "Rainbow Donkey Kong", MACHINE_SUPPORTS_SAVE )
GAME( 2015, dkrdemo,   dkong, dkong2b,   dkrdemo, dkong_state,  empty_init,  ROT270, "Sock Master", "Donkey Kong Remix demo 1.8", MACHINE_SUPPORTS_SAVE )
GAME( 2016, dktrainer, dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Sock Master", "Donkey Kong Trainer 1.01", MACHINE_SUPPORTS_SAVE )
GAME( 2016, dkpace,    dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Sock Master", "Donkey Kong Pace", MACHINE_SUPPORTS_SAVE )
GAME( 2017, dkchrmx,   dkong, dk_braze,  dkongx,  dkong_state,  init_dkongx, ROT270, "Sock Master", "Donkey Kong Christmas Remix", MACHINE_SUPPORTS_SAVE )
GAME( 2018, dkspkyrmx, dkong, dk_braze,  dkongx,  dkong_state,  init_dkongx, ROT270, "Sock Master", "Donkey Kong Spooky Remix", MACHINE_SUPPORTS_SAVE )
GAME( 2022, dkchrte,   dkong, dk_braze,  dkongx,  dkong_state,  init_dkongx, ROT270, "Sock Master", "Donkey Kong Christmas Tournament Edition", MACHINE_SUPPORTS_SAVE )
GAME( 2022, dkongte,   dkong, dk_braze,  dkongx,  dkong_state,  init_dkongx, ROT270, "Sock Master", "Donkey Kong Tournament Edition", MACHINE_SUPPORTS_SAVE )
GAME( 2022, dkspkyte,  dkong, dk_braze,  dkongx,  dkong_state,  init_dkongx, ROT270, "Sock Master", "Donkey Kong Spooky Tournament Edition", MACHINE_SUPPORTS_SAVE )
GAME( 2019, dkongst,   dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Sock Master", "Donkey Kong Springs Trainer", MACHINE_SUPPORTS_SAVE )
GAME( 2020, dkongst2,  dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Sock Master", "Donkey Kong Springs Trainer 2", MACHINE_SUPPORTS_SAVE )
GAME( 2019, dkongrev,  dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Paul Goes", "Donkey Kong Reverse (2019-08-29)", MACHINE_SUPPORTS_SAVE )
GAME( 2019, dkfreerun, dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Paul Goes", "Donkey Kong Freerun Edition (2019-06-20)", MACHINE_SUPPORTS_SAVE )
GAME( 2019, dkcbarrel, dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Paul Goes", "Donkey Kong Crazy Barrels Edition (2019-10-04)", MACHINE_SUPPORTS_SAVE )
GAME( 2020, dkongklc,  dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Paul Goes", "Donkey Kong League Championship v1.00 (2020-02-28)", MACHINE_SUPPORTS_SAVE )
GAME( 2020, dkongce,   dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Paul Goes", "Donkey Kong Championship Edition v1.01 (2020-03-06)", MACHINE_SUPPORTS_SAVE )
GAME( 2020, dkongrnd0, dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Paul Goes", "Donkey Kong Randomized Edition (2020-03-14)", MACHINE_SUPPORTS_SAVE )
GAME( 2020, dkongrnd,  dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Paul Goes", "Donkey Kong Randomized Edition v1.01 (2020-05-01)", MACHINE_SUPPORTS_SAVE )
GAME( 2020, dkongss,   dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Paul Goes", "Donkey Kong Skip Start v1.00 (2020-05-01)", MACHINE_SUPPORTS_SAVE )
GAME( 2020, dkongotr6, dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Paul Goes", "Donkey Kong On the Run (2020-04-29)", MACHINE_SUPPORTS_SAVE )
GAME( 2020, dkongotr7, dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Paul Goes", "Donkey Kong On the Run (2020-05-25)", MACHINE_SUPPORTS_SAVE )
GAME( 2020, dkongotr8, dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Paul Goes", "Donkey Kong On the Run (2020-05-26)", MACHINE_SUPPORTS_SAVE )
GAME( 2020, dkongotr9, dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Paul Goes", "Donkey Kong On the Run (2020-05-26a)", MACHINE_SUPPORTS_SAVE )
GAME( 2020, dkongotr,  dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Paul Goes", "Donkey Kong On the Run v1.02 (2020-05-26)", MACHINE_SUPPORTS_SAVE )
GAME( 2020, dkongitd,  dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Paul Goes", "Donkey Kong In the Dark v1.02 (2020-04-29)", MACHINE_SUPPORTS_SAVE )
GAME( 2020, dkongtj,   dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Paul Goes", "Donkey Kong Twisted Jungle v1.05 (2020-12-12)", MACHINE_SUPPORTS_SAVE )
GAME( 2020, dkjungle0, dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Paul Goes", "Donkey Kong Jungle (2020-07-08)", MACHINE_SUPPORTS_SAVE )
GAME( 2020, dkjungle,  dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Paul Goes", "Donkey Kong Jungle (2020-09-22)", MACHINE_SUPPORTS_SAVE )
GAME( 2020, dktwist0,  dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Paul Goes", "Donkey Kong Twisted (2020-05-18)", MACHINE_SUPPORTS_SAVE )
GAME( 2020, dktwist,   dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Paul Goes", "Donkey Kong Twisted (2020-08-21)", MACHINE_SUPPORTS_SAVE )
GAME( 2020, dkbarpal2, dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Paul Goes", "Donkey Kong Barrelpalooza (2020-11-03)", MACHINE_SUPPORTS_SAVE )
GAME( 2021, dkbarpal3, dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Paul Goes", "Donkey Kong Barrelpalooza v1.03 (2021-03-02)", MACHINE_SUPPORTS_SAVE )
GAME( 2021, dkbarpal4, dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Paul Goes", "Donkey Kong Barrelpalooza v1.04 (2021-04-06)", MACHINE_SUPPORTS_SAVE )
GAME( 2021, dkbarpal5, dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Paul Goes", "Donkey Kong Barrelpalooza v1.05 (2021-04-12)", MACHINE_SUPPORTS_SAVE )
GAME( 2021, dkbarpal6, dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Paul Goes", "Donkey Kong Barrelpalooza v1.06 (2021-05-13)", MACHINE_SUPPORTS_SAVE )
GAME( 2021, dkbarpal,  dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Paul Goes", "Donkey Kong Barrelpalooza v1.07 (2021-06-15)", MACHINE_SUPPORTS_SAVE )
GAME( 2021, dkongan0,  dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Paul Goes", "Donkey Kong 40th Anniversary Edition (2021-01-20)", MACHINE_SUPPORTS_SAVE )
GAME( 2021, dkongan,   dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Paul Goes", "Donkey Kong 40th Anniversary Edition (2021-03-02)", MACHINE_SUPPORTS_SAVE )
GAME( 2021, dkongdu0,  dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Paul Goes", "Donkey Kong Duel v1.00 (2021-11-04)", MACHINE_SUPPORTS_SAVE )
GAME( 2021, dkongdu1,  dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Paul Goes", "Donkey Kong Duel v1.01 (2021-11-08)", MACHINE_SUPPORTS_SAVE )
GAME( 2021, dkongdu,   dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Paul Goes", "Donkey Kong Duel v1.02 (2021-11-10)", MACHINE_SUPPORTS_SAVE )
GAME( 2022, dkwizard0, dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Paul Goes", "Donkey Kong Wizardry v1.00 (2022-02-09)", MACHINE_SUPPORTS_SAVE )
GAME( 2022, dkwizard1, dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Paul Goes", "Donkey Kong Wizardry v1.01 (2022-02-11)", MACHINE_SUPPORTS_SAVE )
GAME( 2022, dkwizard,  dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Paul Goes", "Donkey Kong Wizardry v1.02 (2022-02-13)", MACHINE_SUPPORTS_SAVE )
GAME( 2022, dksprfin,  dkong, dkong2b,   dkong,   dkong_state,  empty_init,  ROT270, "Paul Goes", "Donkey Kong Springfinity v1.01 (2022-04-29)", MACHINE_IS_INCOMPLETE | MACHINE_SUPPORTS_SAVE )

