-- license:BSD-3-Clause
-- copyright-holders:MAMEdev Team

defines {
	"OSD_MINI",
	"USE_QTDEBUG=0",
	"USE_SDL",
	"SDLMAME_NOASM=1",
	"USE_OPENGL=0",
	"NO_USE_MIDI=1",
	"USE_XAUDIO2=0",
}
